/* Historical advisory engine. Pure functions, no DOM. Every card is traceable to variables, formula, thresholds and denominators.
   Classes are application-level analytical labels over HISTORICAL data. They are not regulatory minima, forecasts or clearances. */
const Advisory = ((Calc) => {
  const VERSION = 'FWI-ADV 1.0.0';
  const CLASSES = {
    RED: { label: 'Historical high concern', rank: 5, glyph: '▲' }, AMBER: { label: 'Historical caution', rank: 4, glyph: '◆' },
    YELLOW: { label: 'Historical watch', rank: 3, glyph: '●' }, INFO: { label: 'Historical pattern', rank: 2, glyph: 'i' },
    GREEN: { label: 'No significant exposure identified under the configured analysis', rank: 1, glyph: '✓' }, GREY: { label: 'Insufficient data', rank: 0, glyph: '?' } };
  const DEFAULTS = { bands: { red: 15, amber: 5, yellow: 1 }, th: { vis: 5, ceil: 1500, wind: 25, gust: 30, xw: 15, tail: 5, tHigh: 35, windCompound: 15, minN: 30 },
    provenance: 'Illustrative analysis setting chosen as an application default. Not a regulatory minimum, operator limit or aircraft limit; edit under Configurable thresholds.' };
  const MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  // Class from exposure share. k = qualifying obs, n = valid obs. GREEN only when n is adequate AND k = 0.
  const classify = (k, n, minN, bands = DEFAULTS.bands) => {
    if (!(n >= minN) || n === 0) return 'GREY'; if (k === 0) return 'GREEN';
    const p = 100 * k / n; return p >= bands.red ? 'RED' : p >= bands.amber ? 'AMBER' : p >= bands.yellow ? 'YELLOW' : 'INFO'; };
  const confidence = (n, total, minN) => { if (!(n >= minN)) return 'None'; const comp = total ? n / total : 0; return n >= 1000 && comp >= 0.8 ? 'High' : n >= minN * 10 && comp >= 0.5 ? 'Moderate' : 'Low'; };

  const hasTok = (r, rx, skipVC) => Calc.wxTokens(r.raw).some((t) => rx.test(t) && !(skipVC && t.startsWith('VC')));
  const RWY_BLOCK = 'Runway heading is not confirmed as a TRUE heading. Reported wind direction is relative to true north while runway numbers are magnetic, so runway-relative exposure is not calculated. Enter true headings and confirm on the Wind & Runway tab.';
  const rwyBlocked = (c) => (c.runway && c.runway.trueConfirmed && Number.isFinite(c.runway.hdg) ? null : RWY_BLOCK);
  const comp = (r, hdg) => { const a = (r.wd - hdg) * Math.PI / 180; return { hw: r.ws * Math.cos(a), xw: Math.abs(r.ws * Math.sin(a)) }; };
  const nonCalm = (r) => r.ws != null && r.wd != null && r.ws > 0;

  const RULES = [
    { id: 'vis_low', family: 'Reduced visibility', basis: 'observed', vars: ['vis'], title: (c) => `Visibility below ${c.th.vis} km`, formula: (c) => `vis_km < ${c.th.vis}`,
      blocked: (c) => (c.th.vis > 9.99 ? 'Thresholds of 10 km or more cannot be tested: coded maximum visibility (METAR 9999) is censored at "10 km or more".' : null),
      valid: (r) => r.vis != null, test: (r, c) => r.vis < c.th.vis,
      lim: () => ['Visibility of 10 km or more (METAR 9999) is censored: treated only as "at least 10 km", never as an exact value.', 'Prevailing visibility only; no RVR or runway-specific visibility.'] },
    { id: 'ceil_low', family: 'Low ceiling', title: (c) => `Ceiling below ${c.th.ceil} ft`, formula: (c) => `lowest BKN/OVC/VV layer < ${c.th.ceil} ft AGL`, vars: ['ceiling'],
      basis: (c) => (c.ceilMode === 'metar' ? 'derived' : 'proxy'), blocked: (c) => (c.ceilMode === 'none' ? 'No METAR text or cloud-height column was mapped.' : null),
      valid: (r) => r.ceilKnown, test: (r, c) => r.ceil != null && r.ceil < c.th.ceil,
      lim: (c) => (c.ceilMode === 'metar' ? ['Ceiling is derived from METAR text: lowest BKN, OVC or VV layer. FEW/SCT are not ceilings. Original text is kept for audit.', 'Observations with no BKN/OVC/VV layer count as "no ceiling" in the denominator.']
        : ['PROXY: the mapped cloud-height column is the lowest layer of ANY cover (may include FEW/SCT), so it is not a verified ceiling and over-states low-ceiling exposure.']) },
    { id: 'fog', family: 'Reduced visibility', basis: 'observed', vars: ['METAR present weather'], title: () => 'Fog reported at the station (FG)', formula: () => 'present-weather group contains FG (VCFG excluded)',
      valid: (r) => !!r.raw, test: (r) => hasTok(r, /FG/, true), blocked: (c) => (c.hasRaw ? null : 'Needs raw METAR text; no such column is mapped.'),
      lim: () => ['Based on METAR present-weather codes only. Low visibility or a low cloud base alone is NOT treated as fog.', 'Trend groups (TEMPO/BECMG) are forecasts and are ignored.'] },
    { id: 'thunder', family: 'Thunderstorms', basis: 'observed', vars: ['METAR present weather'], title: () => 'Thunderstorm reported at the station (TS)', formula: () => 'present-weather group contains TS (VCTS excluded)',
      valid: (r) => !!r.raw, test: (r) => hasTok(r, /TS/, true), blocked: (c) => (c.hasRaw ? null : 'Needs raw METAR text; no such column is mapped.'),
      lim: () => ['Counts only explicitly coded TS. High humidity or low cloud never creates a thunderstorm record.', 'Thunderstorms in the vicinity (VCTS) are not counted. No lightning-strike or hail evidence.'] },
    { id: 'wind_strong', family: 'Strong surface winds', basis: 'observed', vars: ['wind speed'], title: (c) => `Mean wind of ${c.th.wind} kt or more`, formula: (c) => `wind_kt >= ${c.th.wind}`,
      valid: (r) => r.ws != null, test: (r, c) => r.ws >= c.th.wind, lim: () => ['Calm (0 kt) observations are included in the denominator.', 'Surface wind alone does not establish turbulence or wind shear.'] },
    { id: 'gust_strong', family: 'Strong surface winds', basis: 'observed', vars: ['wind speed', 'gust'], title: (c) => `Gusts of ${c.th.gust} kt or more`, formula: (c) => `gust_kt >= ${c.th.gust}`,
      valid: (r) => r.ws != null, test: (r, c) => r.gu != null && r.gu >= c.th.gust,
      lim: () => ['Gusts are normally reported only when gusting, so a blank gust is counted as "no gust reported"; this may also include missing data.'] },
    { id: 'xwind', family: 'Crosswind exposure', basis: 'derived', vars: ['wind direction', 'wind speed', 'runway true heading'], title: (c) => `Crosswind component of ${c.th.xw} kt or more`, formula: (c) => `|speed * sin(wind_dir - runway_true_heading)| >= ${c.th.xw}`,
      blocked: rwyBlocked, valid: nonCalm, test: (r, c) => comp(r, c.runway.hdg).xw >= c.th.xw,
      lim: () => ['Calm observations and observations without direction are excluded from the denominator.', 'Uses the runway heading you entered, assumed TRUE; magnetic variation is not applied.', 'Surface wind only; gust-based crosswind is not evaluated.'] },
    { id: 'tailwind', family: 'Crosswind exposure', basis: 'derived', vars: ['wind direction', 'wind speed', 'runway true heading'], title: (c) => `Tailwind component of ${c.th.tail} kt or more`, formula: (c) => `-speed * cos(wind_dir - runway_true_heading) >= ${c.th.tail}`,
      blocked: rwyBlocked, valid: nonCalm, test: (r, c) => -comp(r, c.runway.hdg).hw >= c.th.tail,
      lim: () => ['Evaluated for ONE runway end only (the one selected); the opposite end has the reciprocal exposure.', 'Calm observations and observations without direction are excluded.'] },
    { id: 'temp_high', family: 'Temperature extremes', basis: 'observed', vars: ['temperature'], title: (c) => `Temperature of ${c.th.tHigh} °C or more`, formula: (c) => `temp_c >= ${c.th.tHigh}`,
      valid: (r) => r.T != null, test: (r, c) => r.T >= c.th.tHigh, lim: () => ['Air temperature as reported; no density-altitude or aircraft-performance inference.'] },
    { id: 'compound_vis_wind', family: 'Compound conditions', basis: 'observed', vars: ['vis', 'wind speed'], title: (c) => `Visibility below ${c.th.vis} km with wind of ${c.th.windCompound} kt or more`,
      formula: (c) => `vis_km < ${c.th.vis} AND wind_kt >= ${c.th.windCompound} (same observation)`, blocked: (c) => (c.th.vis > 9.99 ? 'Visibility threshold of 10 km or more cannot be tested (censored).' : null),
      valid: (r) => r.vis != null && r.ws != null, test: (r, c) => r.vis < c.th.vis && r.ws >= c.th.windCompound,
      lim: () => ['Only observations with BOTH variables present are counted, so the denominator is smaller than for either single rule.', 'Co-occurrence in one report does not establish a physical link.'] },
  ];
  const NOT_IMPLEMENTED = ['Turbulence and wind shear (no direct evidence in surface observations)', 'Icing-conducive conditions (no direct evidence; no defensible proxy configured)', 'Density altitude (needs validated airport elevation, temperature and QNH)', 'Precipitation amount or rate (column semantics are not confirmed)', 'RVR (no RVR field)'];

  const strip = (rows, key, n, minN) => rows.map((v, i) => ({ label: key(i), k: v.k, n: v.n, pct: v.n >= minN ? 100 * v.k / v.n : null }));
  const groupBy = (valid, hits, f, size) => { const a = Array.from({ length: size }, () => ({ k: 0, n: 0 })); const hs = new Set(hits); for (const r of valid) { const g = a[f(r)]; g.n++; if (hs.has(r)) g.k++; } return a; };

  const statement = (cd, ctx) => {
    const where = `${ctx.airport || 'the selected airports'}, ${ctx.period || 'the selected period'}`;
    if (cd.cls === 'GREY') return cd.blocked ? `Not assessed: ${cd.blocked}` : `Insufficient historical data to establish a reliable pattern for "${cd.title}" (${cd.n.toLocaleString()} valid observations; minimum ${ctx.minN}).`;
    if (cd.cls === 'GREEN') return `No instance of "${cd.title}" was identified in ${cd.n.toLocaleString()} valid observations for ${where} under the configured analysis. This does not imply zero risk.`;
    const pk = cd.months.peak.length ? ` Most frequent in ${cd.months.peak.map((m) => m.label).join(', ')}.` : '';
    return `Historical records show "${cd.title}" in ${cd.pct.toFixed(cd.pct < 10 ? 2 : 1)}% of valid observations (${cd.k.toLocaleString()} of ${cd.n.toLocaleString()}) for ${where}.${pk}`; };

  // R = filtered records (analysed as a set; airports are not mixed for events). cfg: {th,bands,runway,ceilMode,hasRaw,airport,period,source,airports}
  const analyse = (R, cfg = {}) => {
    const th = { ...DEFAULTS.th, ...(cfg.th || {}) }, bands = { ...DEFAULTS.bands, ...(cfg.bands || {}) }, c = { ...cfg, th, bands, runway: cfg.runway || null, ceilMode: cfg.ceilMode || 'none', hasRaw: cfg.hasRaw ?? R.some((r) => r.raw) };
    const single = new Set(R.map((r) => r.ap)).size <= 1, total = R.length, minN = th.minN;
    const cards = RULES.map((rule) => {
      const title = rule.title(c), blocked = rule.blocked ? rule.blocked(c) : null, basis = typeof rule.basis === 'function' ? rule.basis(c) : rule.basis;
      const valid = blocked ? [] : R.filter(rule.valid), hits = blocked ? [] : valid.filter((r) => rule.test(r, c)), n = valid.length, k = hits.length;
      const cls = blocked ? 'GREY' : classify(k, n, minN, bands), pct = n ? 100 * k / n : null, ok = cls !== 'GREY';
      const mo = strip(groupBy(valid, hits, (r) => r.mo - 1, 12), (i) => MN[i], n, minN), hr = strip(groupBy(valid, hits, (r) => r.h, 24), (i) => String(i).padStart(2, '0') + ':00 UTC', n, minN);
      const peak = mo.filter((m) => m.pct != null && m.k > 0).sort((a, b) => b.pct - a.pct).slice(0, 3);
      let ev = { ok: false, reason: 'Not assessed.' };
      if (ok && k > 0) { if (!single) ev = { ok: false, reason: 'Select a single airport to group observations into events.' };
        else { const e = Calc.events(R, rule.valid, (r) => rule.test(r, c)); ev = e.ok ? { ok: true, count: e.events.length, stepMin: e.step / 6e4, medianDurH: Calc.pctile(e.events.map((x) => x.durMs / 36e5), 50), maxDurH: Math.max(...e.events.map((x) => x.durMs / 36e5)), list: e.events.slice().sort((a, b) => b.durMs - a.durMs || b.n - a.n).slice(0, 10) }
          : { ok: false, reason: e.step == null ? 'Not enough timestamps to assess spacing.' : `Typical spacing between reports is ${(e.step / 6e4).toFixed(0)} min, too coarse to group into events.` }; } }
      const card = { id: rule.id, family: rule.family, title, cls, clsLabel: CLASSES[cls].label, glyph: CLASSES[cls].glyph, k, n, pct, ci: ok ? Calc.wilson(k, n) : null, total, completeness: total ? 100 * n / total : null,
        confidence: ok ? confidence(n, total, minN) : 'None', basis, vars: rule.vars, formula: rule.formula(c), thresholds: { ...th, bands }, provenance: DEFAULTS.provenance,
        months: { all: mo, peak }, hours: { all: hr, peak: hr.filter((h) => h.pct != null && h.k > 0).sort((a, b) => b.pct - a.pct).slice(0, 3) }, events: ev, blocked,
        limitations: [...(rule.lim ? rule.lim(c) : []), 'Share of REPORTED observations, not of hours: reports are unevenly spaced.', 'The 95% interval treats reports as independent; weather persists, so the true uncertainty is wider.'], version: VERSION, dataset: cfg.source || null };
      card.statement = statement(card, { airport: cfg.airport, period: cfg.period, minN }); return card; });
    cards.sort((a, b) => CLASSES[b.cls].rank - CLASSES[a.cls].rank || (b.pct || 0) - (a.pct || 0));
    return { version: VERSION, cards, notImplemented: NOT_IMPLEMENTED, single, total };
  };
  const exportEvidence = (res, cfg) => JSON.stringify({ analysisVersion: res.version, scope: 'HISTORICAL observations only; not current weather, not a forecast, not an operational clearance', airport: cfg.airport, period: cfg.period, source: cfg.source, thresholds: { ...DEFAULTS.th, ...(cfg.th || {}) }, bands: { ...DEFAULTS.bands, ...(cfg.bands || {}) }, runway: cfg.runway || null, ceilingMode: cfg.ceilMode, advisories: res.cards.map(({ months, hours, ...x }) => ({ ...x, months: months.all, hours: hours.all })), notImplemented: res.notImplemented }, null, 2);
  const api = { VERSION, CLASSES, DEFAULTS, classify, confidence, analyse, exportEvidence, RULES, NOT_IMPLEMENTED };
  return api;
})(typeof Calc !== 'undefined' ? Calc : require('./calc.js'));
if (typeof module !== 'undefined') module.exports = Advisory;
