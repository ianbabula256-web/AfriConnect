# Changelog

## Phase 1 - trust and correctness
- Removed stale `test/ops.test.js` (tested a deleted live-weather module and failed); `npm test` now runs every test file.
- Fixed build: cloud images were never copied to `dist/`; service worker now precaches them (cache `wx-v6`).
- Removed dead `opsAfter` hook; product title is now FORBSPACE Historical Weather Intelligence.
- Added: exact/conflicting duplicate handling, rejected-row list, censored-visibility flag, pressure-type tracking (QNH / station / sea-level / unstated), METAR present-weather and cloud parsing that ignores TEMPO/BECMG/NOSIG/RMK trend groups.
- Runway-relative analysis now requires the user to confirm headings are TRUE.

## Phase 3 - advisory engine
- New `src/advisory.js` (FWI-ADV 1.0.0) and rewritten Historical Advisories tab.

## Phase 5 (partial) - replay
- New `src/scene.js` and Historical Replay tab (2D canvas, procedural clouds). Removed the hand-drawn cartoon storm/aircraft scene and dead CSS.
