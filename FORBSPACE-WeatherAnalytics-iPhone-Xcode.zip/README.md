# Weather Analytics — platform projects
- `iPhone-Xcode/`      Xcode project sources (needs a Mac + Xcode)
- `Android-Studio/`    Android Studio project (Kotlin WebView)
- `Windows-Electron/`  Electron desktop app (Node.js)
Each folder has its own README with step-by-step build instructions. All three bundle the same offline web app plus the animated sky page, and add native Save for the Export buttons.
Status: web app tested in a browser with a mock native bridge; the native shells were NOT compiled or run in the build environment.
