# Weather Analytics — iPhone / iPad (Xcode project)

Wraps the offline web app in a native iOS app. Everything is bundled in `www/`; no internet is needed.

## What you need
- A **Mac** with **Xcode 15+** (free, Mac App Store). iPhone apps cannot be built on Windows or on the phone itself.
- Your iPhone and a free **Apple ID** (apps signed with a free account expire after 7 days). TestFlight / App Store needs a paid Apple Developer account.

## Build and run (easy way, XcodeGen)
1. Install XcodeGen once: `brew install xcodegen`
2. In this folder run `xcodegen` — it creates `WeatherAnalytics.xcodeproj`.
3. Open it in Xcode → target **WeatherAnalytics** → **Signing & Capabilities** → choose your Team (your Apple ID).
4. Plug in the iPhone, select it at the top, press **Run**. On the phone: Settings → General → VPN & Device Management → trust the developer.

## Build and run (without XcodeGen)
1. Xcode → File → New → Project → iOS **App** (SwiftUI, Swift), name `WeatherAnalytics`, bundle id `com.forbspace.weather`.
2. Delete the generated Swift files; drag in the two files from `Sources/`.
3. Drag the `www` folder in and choose **Create folder references** (blue folder), tick the target.
4. Use `WeatherAnalytics.xcassets/AppIcon.appiconset/icon-1024.png` as the app icon. Run.

## Notes
- Export buttons open the iOS share sheet — choose **Save to Files**.
- To open the animated sky page instead, change `startPage` in `Sources/WebContainer.swift` to `"weather-flow-aviation.html"`.
- To update the web app, replace the files in `www/` and rebuild.
- **Not compiled or run here** (no Xcode in the build environment). If Xcode shows an error, send me the message.
