import SwiftUI

@main
struct WeatherAnalyticsApp: App {
    var body: some Scene {
        WindowGroup {
            WebContainer()
                .ignoresSafeArea()          // the web pages handle safe areas with env(safe-area-inset-*)
                .background(Color(red: 0.02, green: 0.07, blue: 0.16))
        }
    }
}
