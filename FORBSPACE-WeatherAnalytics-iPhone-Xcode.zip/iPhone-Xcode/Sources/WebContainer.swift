import SwiftUI
import WebKit
import UIKit

/// Shows the bundled web app (folder "www") in a WKWebView, fully offline.
/// Change startPage to "weather-flow-aviation.html" to open the animated sky page instead.
struct WebContainer: UIViewRepresentable {
    static let startPage = "index.html"

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.userContentController.add(context.coordinator, name: "nativeSave") // used by the app's Export buttons
        let web = WKWebView(frame: .zero, configuration: config)
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.scrollView.bounces = false
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 0.02, green: 0.07, blue: 0.16, alpha: 1)
        if #available(iOS 16.4, *) { web.isInspectable = true } // Safari > Develop for debugging
        if let dir = Bundle.main.url(forResource: "www", withExtension: nil) {
            web.loadFileURL(dir.appendingPathComponent(Self.startPage), allowingReadAccessTo: dir)
        }
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKScriptMessageHandler {
        /// Receives {name, text, type} from the page and opens the iOS share sheet (Save to Files, AirDrop, ...).
        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            guard let body = message.body as? [String: Any],
                  let name = body["name"] as? String,
                  let text = body["text"] as? String else { return }
            let safeName = name.replacingOccurrences(of: "/", with: "_")
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
            do { try text.write(to: url, atomically: true, encoding: .utf8) } catch { return }
            DispatchQueue.main.async {
                guard let root = UIApplication.shared.connectedScenes
                    .compactMap({ ($0 as? UIWindowScene)?.keyWindow }).first?.rootViewController else { return }
                let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
                share.popoverPresentationController?.sourceView = root.view
                root.present(share, animated: true)
            }
        }
    }
}
