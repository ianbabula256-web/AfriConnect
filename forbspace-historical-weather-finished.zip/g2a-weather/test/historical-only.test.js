const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const template=fs.readFileSync(path.join(root,'src/app.template.html'),'utf8');
const build=fs.readFileSync(path.join(root,'build.js'),'utf8');

test('historical-only source has no live weather integrations',()=>{
  for(const file of ['src/app.template.html','build.js','public/sw.js','README.md']){
    const s=fs.readFileSync(path.join(root,file),'utf8');
    assert.doesNotMatch(s,/aviationweather\.gov\/api|worker-ops|weather-flow-aviation|setInterval\([^\n]*refresh|METAR \/ TAF tab|TAF retrieval/i,`${file} contains a live-weather dependency`);
  }
});

test('live-weather files are removed',()=>{
  for(const file of ['worker-ops-proxy.js','src/ops.js','src/opsui.js','public/weather-flow-aviation.html','dist/weather-flow-aviation.html']){
    assert.equal(fs.existsSync(path.join(root,file)),false,file+' should not exist');
  }
});

test('historical navigation remains',()=>{
  for(const label of ['Import Historical Data','Overview','Wind & Runway','Pressure + Clouds','Temperature & Moisture','Visibility','Historical Advisories','Data & Sources']) assert.match(template,new RegExp(label.replace(/[+]/g,'\\+')));
});
