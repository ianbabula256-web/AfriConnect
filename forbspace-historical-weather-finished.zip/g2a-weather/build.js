const fs=require('fs');
fs.mkdirSync('dist',{recursive:true});
const strip=f=>fs.readFileSync(f,'utf8').replace(/if \(typeof module[^\n]*\n?/,'');
const template=fs.readFileSync('src/app.template.html','utf8');
const calc=strip('src/calc.js');
fs.writeFileSync('dist/index.html',template.replace('/*CALC*/',()=>calc));
for(const f of ['manifest.webmanifest','sw.js','icon.svg','apple-touch-icon.png','icon-192.png','icon-512.png','icon-maskable-512.png']) fs.copyFileSync('public/'+f,'dist/'+f);
console.log('built historical-only dist/index.html');
