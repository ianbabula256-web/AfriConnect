# FORBSPACE Historical Weather Intelligence

Historical-only aviation weather analytics application. The application does **not** retrieve, monitor, refresh, or forecast current/future weather.

## Historical-only boundary
- Weather information is sourced from datasets explicitly imported by the user.
- Current METAR/SPECI, TAF, SIGMET/AIRMET, live alerts, live weather maps, polling, and live operational weather advice have been removed.
- Missing historical records are never replaced with current conditions.
- The 3D/atmospheric presentation layer, where used, is illustrative and must not be interpreted as a photographic reconstruction of the historical sky.

## Run
```bash
node build.js
npx serve dist
# or
python3 -m http.server -d dist 3000
```

## Tests
```bash
node --test test/calc.test.js test/historical-only.test.js
```

## Import
Use the **Import Historical Data** tab and load CSV, XLSX, or JSON historical observations. Confirm field mappings and units before analysis.

Recommended historical fields include timestamp, airport/station, wind direction, wind speed, gust, pressure/QNH, visibility, temperature, dew point, relative humidity, cloud height/ceiling semantics, precipitation, and raw historical METAR text where available.

## Analytical boundary
Historical exposure labels are analytical classifications only. They are not regulatory minima, operational clearances, forecasts, or declarations that an airport or flight is safe/unsafe.
