// Optional Cloudflare Worker: read-only, CORS-enabled proxy for the NOAA Aviation Weather Center data API.
// Why: browsers often block direct requests to other sites (CORS). This worker fetches server-side and adds CORS headers.
// Deploy: Cloudflare dashboard -> Workers & Pages -> Create Worker -> paste this file -> Deploy.
// Then set an environment variable ALLOW_ORIGIN to your site (e.g. https://yourname.github.io) and paste the worker URL
// into the app: METAR / TAF tab -> Source "My proxy". No API keys are needed for aviationweather.gov.
// Untested in the build environment (no network there).
const ALLOW = ['metar', 'taf', 'isigmet', 'airsigmet', 'windtemp'];
export default {
  async fetch(req, env) {
    const u = new URL(req.url), path = u.pathname.replace(/^\/+/, '');
    const cors = { 'Access-Control-Allow-Origin': env.ALLOW_ORIGIN || '*', 'Access-Control-Allow-Methods': 'GET', 'Vary': 'Origin' };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (req.method !== 'GET' || !ALLOW.includes(path)) return new Response('Not found', { status: 404, headers: cors });
    const up = new URL('https://aviationweather.gov/api/data/' + path);
    u.searchParams.forEach((v, k) => up.searchParams.set(k, v));
    const r = await fetch(up.toString(), { headers: { 'User-Agent': 'ops-proxy' }, cf: { cacheTtl: 60, cacheEverything: true } });
    return new Response(r.body, { status: r.status, headers: { ...cors, 'Content-Type': r.headers.get('Content-Type') || 'text/plain', 'Cache-Control': 'public, max-age=60' } });
  }
};
