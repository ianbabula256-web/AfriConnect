# Airport Weather Analytics

Static, client-side web app (vanilla JS + inline SVG, no build dependencies). Chosen so it runs anywhere, keeps uploaded data in the browser, and has nothing to host server-side. XLSX is read by a built-in reader (no external library); the app works fully offline once visited.

## Run
    node build.js            # writes dist/ (index.html, manifest, sw.js, icon)
    npx serve dist           # or: python3 -m http.server -d dist  → open http://localhost:3000
    node --test test/calc.test.js    # tests (set DATA=/path/file.csv for the integration test)

## Load data
Import tab → choose a CSV/XLSX/JSON file (or a URL if the host allows CORS) → confirm column mapping and units → Validate & load.
Data stays in browser memory only; nothing is uploaded or saved. Reloading clears it.

## Deploy
Upload the contents of `dist/` to any static host (Netlify, GitHub Pages, Cloudflare Pages, S3). HTTPS is required for the PWA.
Install on a phone: open the site → Share/⋮ menu → "Add to Home Screen". Install on desktop: browser address-bar install icon.

## Layout
`src/calc.js` parsing + statistics (tested) · `src/app.template.html` UI · `build.js` inlines calc into one page.

## Offline use
Open the hosted https address once while online; a service worker then stores the app on the device (header shows "ready to work offline").
Upload ALL files from dist/ (index.html, sw.js, manifest.webmanifest, icon.svg, apple-touch-icon.png). On iPhone use Share → Add to Home Screen so Safari keeps the stored copy.
To release an update, change `V` in public/sw.js (e.g. wx-v3) and rebuild so devices refresh their stored copy.
Loaded datasets are not stored; choose the file again after a reload (works offline from the Files app).

## Ops module (Ops · METAR / TAF · Alerts & hazards · Tools · Aircraft tabs)
- **Reports**: paste/upload METAR, SPECI and TAF, or fetch from aviationweather.gov directly or through `worker-ops-proxy.js` (recommended; deploy steps are in that file). Auto-refresh 5–60 min (default 30). Last 30 reports per station and the aircraft list are cached in this browser (localStorage); uploaded weather *history* files are still never stored.
- **Aircraft**: upload CSV/XLSX/JSON (e.g. `G2A_Models_Datasets.xlsx` — pick a sheet, map columns). The G2A workbook has types and MTOW only; crosswind/tailwind/temperature/icing/minima must be entered. `aircraft_profiles_from_G2A.csv` is a ready file (398 types, derived Light/Medium/Heavy, blank limits).
- **Advice** is decision support against limits you configure. It never says safe/unsafe and does not generate aircraft procedures.
- **Background**: `weather-flow-aviation.html` is loaded as a hidden frame on the Ops tabs and driven by the latest METAR (thunderstorm, fog, rain, wind, cloud, clear; night). Keep it next to `index.html`.
- Tests: `node --test test/calc.test.js test/ops.test.js` (26).
