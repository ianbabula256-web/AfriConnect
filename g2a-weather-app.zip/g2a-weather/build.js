const fs=require('fs');fs.mkdirSync('dist',{recursive:true});
const calc=fs.readFileSync('src/calc.js','utf8').replace(/if \(typeof module[^\n]*\n?/,'');
const strip=f=>fs.readFileSync(f,'utf8').replace(/if \(typeof module[^\n]*\n?/,'');
fs.writeFileSync('dist/index.html',fs.readFileSync('src/app.template.html','utf8').replace('/*CALC*/',()=>calc).replace('/*OPS*/',()=>strip('src/ops.js')).replace('/*OPSUI*/',()=>fs.readFileSync('src/opsui.js','utf8')));
for(const f of ['manifest.webmanifest','sw.js','icon.svg','apple-touch-icon.png','icon-192.png','icon-512.png','icon-maskable-512.png','weather-flow-aviation.html'])fs.copyFileSync('public/'+f,'dist/'+f);console.log('built dist/index.html');
