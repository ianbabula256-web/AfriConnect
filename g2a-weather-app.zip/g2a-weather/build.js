const fs=require('fs');fs.mkdirSync('dist',{recursive:true});
const calc=fs.readFileSync('src/calc.js','utf8').replace(/if \(typeof module[^\n]*\n?/,'');
fs.writeFileSync('dist/index.html',fs.readFileSync('src/app.template.html','utf8').replace('/*CALC*/',()=>calc));
for(const f of ['manifest.webmanifest','sw.js','icon.svg','apple-touch-icon.png','icon-192.png','icon-512.png','icon-maskable-512.png'])fs.copyFileSync('public/'+f,'dist/'+f);console.log('built dist/index.html');
