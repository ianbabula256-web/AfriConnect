/* Pure calculation layer: parsing, normalisation, filters, statistics. No DOM. */
const Calc = (() => {
  const parseCSV = (text) => {
    const rows = []; let r = [], f = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
      else if (c === '"') q = true;
      else if (c === ',') { r.push(f); f = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; r.push(f); f = ''; if (r.length > 1 || r[0] !== '') rows.push(r); r = []; }
      else f += c;
    }
    if (f !== '' || r.length) { r.push(f); rows.push(r); }
    return { headers: rows.shift() || [], rows };
  };
  const FIELDS = ['airport','time','wdir','wspd','gust','pres','vis','temp','dew','rh','cloud','precip','metar'];
  const RX = { airport:/station|airport|icao|ident/i, time:/date|time|valid/i, gust:/gust/i, wdir:/wind\s*dir|wdir|drct/i,
    wspd:/wind\s*speed|wspd|sknt/i, pres:/altim|qnh|pressure|slp/i, vis:/visib/i, dew:/dew/i, rh:/humid|relh|\brh\b/i,
    temp:/temp|tmp/i, cloud:/cloud|ceil/i, precip:/precip|rain|p01/i, metar:/metar|raw/i };
  const guessMap = (headers) => {
    const map = {}, used = new Set();
    for (const k of ['gust','wdir','wspd','dew','rh','pres','vis','precip','metar','cloud','time','airport','temp']) {
      const i = headers.findIndex((h, j) => !used.has(j) && RX[k].test(h) && !(k === 'temp' && /dew/i.test(h)));
      map[k] = i; if (i >= 0) used.add(i);
    }
    return map;
  };
  const guessUnits = (headers, map) => {
    const h = (k) => (map[k] >= 0 ? headers[map[k]] : '');
    return {
      wspd: /m\/s|mps/i.test(h('wspd')) ? 'mps' : /km\/h|kmh/i.test(h('wspd')) ? 'kmh' : 'kt',
      pres: /inch|\(in\)|inhg/i.test(h('pres')) ? 'inHg' : /kpa/i.test(h('pres')) ? 'kPa' : 'hPa',
      vis: /mile|\(mi\)/i.test(h('vis')) ? 'mi' : /\bkm\b/i.test(h('vis')) ? 'km' : /meter|\(m\)/i.test(h('vis')) ? 'm' : 'km',
      cloud: /\(m\)|meter/i.test(h('cloud')) ? 'm' : 'ft',
    };
  };
  const K = { wspd:{kt:1,mps:1.943844,kmh:0.539957}, pres:{hPa:1,inHg:33.8639,kPa:10}, vis:{km:1,mi:1.609344,m:0.001}, cloud:{ft:1,m:3.28084} };
  const num = (v) => { if (v == null) return null; const s = String(v).trim(); if (!s || /^(null|nan|m|na|n\/a|-)$/i.test(s)) return null; const x = parseFloat(s); return Number.isFinite(x) ? x : null; };
  const parseTime = (v) => {
    const s = String(v ?? '').trim(); if (!s) return null;
    if (/^\d+(\.\d+)?$/.test(s) && +s > 20000 && +s < 80000) return Math.round((+s - 25569) * 86400000); // Excel serial date (UTC)
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?(Z|[+-]\d{2}:?\d{2})?$/);
    if (m && !m[7]) return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
    const t = Date.parse(s); return Number.isFinite(t) ? t : null;
  };
  const ceilFromMetar = (s) => { // lowest BKN/OVC/VV layer in ft AGL; null = none reported
    let best = null; for (const m of String(s).matchAll(/\b(BKN|OVC|VV)(\d{3})\b/g)) { const h = +m[2] * 100; if (best == null || h < best) best = h; }
    return best;
  };
  const normalise = (table, map, units) => {
    const g = (row, k) => (map[k] >= 0 ? row[map[k]] : null);
    const recs = []; const meta = { rows: table.rows.length, badTime: 0, ceilMode: map.metar >= 0 ? 'metar' : map.cloud >= 0 ? 'lowest-layer' : 'none', conversions: [] };
    if (map.metar >= 0) meta.conversions.push('Ceiling = lowest BKN/OVC/VV layer parsed from the METAR text (FEW/SCT are not ceilings). No such layer = "no ceiling".');
    else if (map.cloud >= 0) meta.conversions.push('No METAR text mapped: the mapped cloud-height column is used as-is and is the lowest layer of ANY cover (may include FEW/SCT), so it is not a true ceiling.');
    if (units.wspd !== 'kt') meta.conversions.push(`Wind speed ${units.wspd} → kt (×${K.wspd[units.wspd]}).`);
    if (units.pres !== 'hPa') meta.conversions.push(`Pressure ${units.pres} → hPa (×${K.pres[units.pres]}).`);
    if (units.vis !== 'km') meta.conversions.push(`Visibility ${units.vis} → km (×${K.vis[units.vis]}).`);
    meta.conversions.push('Timestamps without a timezone are treated as UTC (the file does not state a timezone).');
    meta.conversions.push('Wind direction 0° is treated as 360° (north). Calm = speed 0 kt; calm winds are excluded from direction and runway statistics.');
    table.rows.forEach((row, i) => {
      const t = parseTime(g(row, 'time')); if (t == null) { meta.badTime++; return; }
      const d = new Date(t); const metar = map.metar >= 0 ? String(row[map.metar] ?? '') : '';
      const cl = num(g(row, 'cloud')); const cloudFt = cl == null ? null : cl * K.cloud[units.cloud];
      const sc = (k, f) => { const x = num(g(row, k)); return x == null ? null : x * f; };
      let wd = num(g(row, 'wdir')); if (wd === 0) wd = 360; if (wd != null && (wd < 0 || wd > 360)) wd = null;
      recs.push({ id: i, ap: String(g(row, 'airport') ?? 'UNKNOWN').trim() || 'UNKNOWN', t, y: d.getUTCFullYear(), mo: d.getUTCMonth() + 1, h: d.getUTCHours(),
        wd, ws: sc('wspd', K.wspd[units.wspd]), gu: sc('gust', K.wspd[units.wspd]), p: sc('pres', K.pres[units.pres]), vis: sc('vis', K.vis[units.vis]),
        T: num(g(row, 'temp')), Td: num(g(row, 'dew')), rh: num(g(row, 'rh')), pr: num(g(row, 'precip')),
        ceil: map.metar >= 0 ? (metar ? ceilFromMetar(metar) : undefined) : cloudFt, ceilKnown: map.metar >= 0 ? !!metar : cloudFt != null, raw: metar });
    });
    meta.used = recs.length; return { recs, meta };
  };
  const filter = (recs, f) => recs.filter((r) => (!f.ap || r.ap === f.ap) && r.y >= f.y0 && r.y <= f.y1 && (!f.mo || r.mo === f.mo) && (f.hr < 0 || r.h === f.hr));
  const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : null);
  const pctile = (a, p) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const i = (s.length - 1) * p / 100, lo = Math.floor(i); return s[lo] + (s[Math.min(lo + 1, s.length - 1)] - s[lo]) * (i - lo); };
  const lgam = (x) => { const c = [76.18009172947146,-86.50532032941677,24.01409824083091,-1.231739572450155,0.1208650973866179e-2,-0.5395239384953e-5]; let y = x, t = x + 5.5; t -= (x + .5) * Math.log(t); let s = 1.000000000190015; for (const k of c) s += k / ++y; return -t + Math.log(2.5066282746310005 * s / x); };
  const betacf = (a, b, x) => { const T = 1e-30; let c = 1, d = 1 - (a + b) * x / (a + 1); if (Math.abs(d) < T) d = T; d = 1 / d; let h = d;
    for (let m = 1; m <= 200; m++) { const m2 = 2 * m; let aa = m * (b - m) * x / ((a - 1 + m2) * (a + m2)); d = 1 + aa * d; if (Math.abs(d) < T) d = T; c = 1 + aa / c; if (Math.abs(c) < T) c = T; d = 1 / d; h *= d * c;
      aa = -(a + m) * (a + b + m) * x / ((a + m2) * (a + 1 + m2)); d = 1 + aa * d; if (Math.abs(d) < T) d = T; c = 1 + aa / c; if (Math.abs(c) < T) c = T; d = 1 / d; const del = d * c; h *= del; if (Math.abs(del - 1) < 3e-12) break; } return h; };
  const ibeta = (x, a, b) => { if (x <= 0) return 0; if (x >= 1) return 1; const bt = Math.exp(lgam(a + b) - lgam(a) - lgam(b) + a * Math.log(x) + b * Math.log(1 - x)); return x < (a + 1) / (a + b + 2) ? bt * betacf(a, b, x) / a : 1 - bt * betacf(b, a, 1 - x) / b; };
  const ols = (xs, ys) => { const n = xs.length; if (n < 3) return null; const mx = mean(xs), my = mean(ys); let sxx = 0, sxy = 0, syy = 0;
    xs.forEach((x, i) => { sxx += (x - mx) ** 2; sxy += (x - mx) * (ys[i] - my); syy += (ys[i] - my) ** 2; });
    const slope = sxy / sxx, icpt = my - slope * mx, sse = syy - slope * sxy, df = n - 2; const se = Math.sqrt(sse / df / sxx);
    const p = se === 0 ? 0 : ibeta(df / (df + (slope / se) ** 2), df / 2, .5); return { slope, icpt, n, r2: syy ? 1 - sse / syy : 0, p }; };
  const sector = (d) => Math.floor((((d % 360) + 360) % 360 + 11.25) / 22.5) % 16;
  const BANDS = [0, 5, 10, 15, 20];
  const rose = (R) => { const counts = Array.from({ length: 16 }, () => [0, 0, 0, 0, 0]); const sp = Array.from({ length: 16 }, () => []); let calm = 0, n = 0, nd = 0;
    for (const r of R) { if (r.ws == null) continue; n++; if (r.ws === 0) { calm++; continue; } if (r.wd == null) continue; nd++; const s = sector(r.wd); let b = 0; BANDS.forEach((e, i) => { if (r.ws >= e && r.ws > 0) b = i; }); counts[s][b]++; sp[s].push(r.ws); }
    return { n, calm, nd, counts, sp }; };
  const components = (R, hdg, th) => { let n = 0, head = 0, tail = 0, tailX = 0, xwX = 0; const xs = [];
    for (const r of R) { if (r.ws == null || r.wd == null || r.ws === 0) continue; n++; const a = (r.wd - hdg) * Math.PI / 180; const hw = r.ws * Math.cos(a), xw = Math.abs(r.ws * Math.sin(a));
      if (hw > 0) head++; else if (hw < 0) tail++; if (hw <= -th.tail) tailX++; if (xw >= th.xw) xwX++; xs.push(xw); }
    return { n, head, tail, tailX, xwX, xwP90: pctile(xs, 90) }; };
  const group = (R, keyFn, valFn) => { const m = new Map(); for (const r of R) { const k = keyFn(r), v = valFn(r); if (v == null) continue; (m.get(k) || m.set(k, []).get(k)).push(v); } return m; };
  const share = (R, valid, test) => { let n = 0, k = 0; for (const r of R) { if (!valid(r)) continue; n++; if (test(r)) k++; } return { n, k, pct: n ? 100 * k / n : null }; };
  const CORE = ['wd', 'ws', 'p', 'vis', 'T'];
  const missing = (R) => Object.fromEntries(['wd','ws','gu','p','vis','T','Td','rh','pr','ceilKnown'].map((k) => [k, R.length ? 100 * R.filter((r) => r[k] == null || r[k] === false).length / R.length : null]));
  const csvCell = (v) => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const toCSV = (R) => { const cols = ['id','ap','t','wd','ws','gu','p','vis','ceil','T','Td','rh','raw']; return ['source_row,airport,utc_time,wind_dir_deg,wind_kt,gust_kt,qnh_hpa,vis_km,ceiling_ft,temp_c,dewpoint_c,rh_pct,metar'].concat(R.map((r) => cols.map((c) => csvCell(c === 't' ? new Date(r.t).toISOString() : c === 'id' ? r.id + 2 : r[c])).join(','))).join('\n'); };
  const api = { parseCSV, guessMap, guessUnits, normalise, filter, mean, pctile, ols, sector, rose, components, group, share, missing, toCSV, ceilFromMetar, parseTime, FIELDS, BANDS, CORE };
  return api;
})();
if (typeof module !== 'undefined') module.exports = Calc;
