/* Aviation weather logic. Pure functions (no DOM). All times UTC. Advisory only — never operational clearance. */
const Ops = (() => {
  const KT = 1.943844, R = Math.PI / 180;
  const WXD = { MI: 'shallow', PR: 'partial', BC: 'patches of', DR: 'low drifting', BL: 'blowing', SH: 'showers of', TS: 'thunderstorm with', FZ: 'freezing' };
  const WXP = { DZ: 'drizzle', RA: 'rain', SN: 'snow', SG: 'snow grains', IC: 'ice crystals', PL: 'ice pellets', GR: 'hail', GS: 'small hail', UP: 'unknown precipitation', BR: 'mist', FG: 'fog', FU: 'smoke', VA: 'volcanic ash', DU: 'dust', SA: 'sand', HZ: 'haze', PY: 'spray', PO: 'dust whirls', SQ: 'squalls', FC: 'funnel cloud', SS: 'sandstorm', DS: 'duststorm' };
  const COV = { FEW: 'few clouds', SCT: 'scattered clouds', BKN: 'broken cloud', OVC: 'overcast' };
  const WXRX = /^(\+|-|VC)?((?:MI|PR|BC|DR|BL|SH|TS|FZ)*)((?:DZ|RA|SN|SG|IC|PL|GR|GS|UP|BR|FG|FU|VA|DU|SA|HZ|PY|PO|SQ|FC|SS|DS)*)$/;
  const pad = (n, w = 2) => String(n).padStart(w, '0');
  const wxText = (t) => { const m = t.match(WXRX); if (!m || !(m[2] || m[3])) return null; const w = { '+': 'heavy ', '-': 'light ' }[m[1]] || ''; let d = (m[2].match(/../g) || []).map((x) => WXD[x]).join(' '); const p = (m[3].match(/../g) || []).map((x) => WXP[x]).join(' and ');
    let s = (w + d + ' ' + p).replace(/\s+/g, ' ').trim(); if (/with $/.test(s + ' ')) s = s.replace(/ with$/, ''); return s + (m[1] === 'VC' ? ' in the vicinity' : ''); };
  /* parse weather/wind/vis/cloud tokens into a condition object (shared by METAR, trend and TAF groups) */
  function cond(tokens, c = {}) {
    c.wx = c.wx || []; c.clouds = c.clouds || []; c.rvr = c.rvr || [];
    for (const t of tokens) { let m;
      if (t === 'CAVOK') { c.cavok = true; c.vis = 10000; c.clouds = []; c.wx = []; continue; }
      if (t === 'NSW') { c.wx = []; continue; }
      if (t === 'NSC' || t === 'NCD' || t === 'SKC' || t === 'CLR') { c.clouds = []; c.clear = t; continue; }
      if ((m = t.match(/^(VRB|\d{3})(P?\d{2,3})(?:G(P?\d{2,3}))?(KT|MPS|KMH)$/))) { const f = m[4] === 'KT' ? 1 : m[4] === 'MPS' ? KT : .539957, n = (s) => s ? Math.round(+s.replace('P', '') * f) : null; c.wind = { dir: m[1] === 'VRB' ? null : +m[1], spd: n(m[2]), gst: n(m[3]) }; continue; }
      if ((m = t.match(/^(\d{3})V(\d{3})$/))) { c.wvar = [+m[1], +m[2]]; continue; }
      if (/^\d{4}$/.test(t) && c.vis == null) { c.vis = +t; continue; }
      if ((m = t.match(/^(?:P|M)?(\d+)SM$/)) && c.vis == null) { c.vis = Math.round(+m[1] * 1609); continue; }
      if ((m = t.match(/^R(\d{2}[LCR]?)\/([PM]?)(\d{4})(?:V([PM]?)(\d{4}))?(?:FT)?([UDN])?$/))) { c.rvr.push({ rwy: m[1], v: +m[3], pm: m[2], v2: m[5] ? +m[5] : null, tr: m[6] || '' }); continue; }
      if ((m = t.match(/^(FEW|SCT|BKN|OVC)(\d{3}|\/\/\/)(CB|TCU)?$/))) { c.clouds.push({ cov: m[1], ft: m[2] === '///' ? null : +m[2] * 100, type: m[3] || '' }); continue; }
      if ((m = t.match(/^VV(\d{3}|\/\/\/)$/))) { c.clouds.push({ cov: 'VV', ft: m[1] === '///' ? null : +m[1] * 100, type: '' }); continue; }
      if (WXRX.test(t) && t.length >= 2 && wxText(t)) { c.wx.push(t); continue; }
    }
    return c;
  }
  const dayMs = (dd, hh, mm, now = Date.now()) => { const n = new Date(now); let d = Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), dd, hh, mm); if (d > now + 36e5 * 36) d = Date.UTC(n.getUTCFullYear(), n.getUTCMonth() - 1, dd, hh, mm); return d; };
  function metar(raw, now = Date.now()) {
    const s = String(raw).replace(/=\s*$/, '').trim(), tk = s.split(/\s+/), o = { raw: s, type: 'METAR', cor: false, auto: false, trend: null }; let i = 0;
    if (tk[0] === 'METAR' || tk[0] === 'SPECI') o.type = tk[i++];
    if (tk[i] === 'COR') { o.cor = true; i++; }
    if (/^[A-Z][A-Z0-9]{3}$/.test(tk[i])) o.icao = tk[i++];
    let m = (tk[i] || '').match(/^(\d{2})(\d{2})(\d{2})Z$/); if (m) { o.t = dayMs(+m[1], +m[2], +m[3], now); o.z = tk[i]; i++; }
    const body = [], tr = []; let inTr = false, rmk = [];
    for (; i < tk.length; i++) { const t = tk[i];
      if (t === 'AUTO') { o.auto = true; continue; } if (t === 'COR') { o.cor = true; continue; }
      if (t === 'RMK') { rmk = tk.slice(i + 1); break; }
      if (/^(NOSIG|BECMG|TEMPO)$/.test(t)) { inTr = true; o.trend = { type: t, c: {}, times: [] }; continue; }
      if (inTr) { if (/^(FM|TL|AT)\d{4}$/.test(t)) o.trend.times.push(t); else tr.push(t); continue; }
      body.push(t); }
    for (const t of body) { let q;
      if ((q = t.match(/^(M?\d{2})\/(M?\d{2})?$/))) { const f = (x) => x[0] === 'M' ? -x.slice(1) : +x; o.temp = f(q[1]); o.dew = q[2] ? f(q[2]) : null; continue; }
      if ((q = t.match(/^Q(\d{4})$/))) { o.qnh = +q[1]; continue; }
      if ((q = t.match(/^A(\d{4})$/))) { o.inhg = +q[1] / 100; o.qnh = Math.round(+q[1] / 100 * 33.8639); continue; }
      if ((q = t.match(/^QFE(\d{3,4})$/))) { o.qfe = +q[1]; continue; } }
    cond(body.filter((t) => !/^(M?\d{2})\/(M?\d{2})?$/.test(t) && !/^[QA]\d{4}$/.test(t) && !/^QFE/.test(t)), o);
    if (o.trend) cond(tr, o.trend.c); o.rmk = rmk.join(' '); return o;
  }
  const ceiling = (c) => { let h = null; for (const k of c.clouds || []) if ((k.cov === 'BKN' || k.cov === 'OVC' || k.cov === 'VV') && k.ft != null && (h == null || k.ft < h)) h = k.ft; return h; };
  const hasTS = (c) => (c.wx || []).some((w) => /TS/.test(w)) || (c.clouds || []).some((k) => k.type === 'CB');
  const hasCB = (c) => (c.clouds || []).some((k) => k.type === 'CB' || k.type === 'TCU') || (c.wx || []).some((w) => /^VC?TS|TS/.test(w));
  /* FAA-style categories (ICAO states may publish their own minima) */
  function category(c) {
    const v = c.vis == null ? (c.cavok ? 10000 : null) : c.vis, h = ceiling(c); if (v == null && h == null && !(c.clouds || []).length && !c.cavok && !c.clear) return null;
    let cat = 'VFR', why = [];
    const step = (cc, r) => { const o = ['VFR', 'MVFR', 'IFR', 'LIFR']; if (o.indexOf(cc) > o.indexOf(cat)) { cat = cc; why = [r]; } else if (cc === cat && cc !== 'VFR') why.push(r); };
    if (v != null) { if (v < 1600) step('LIFR', 'visibility ' + v + ' m'); else if (v < 4800) step('IFR', 'visibility ' + v + ' m'); else if (v <= 8000) step('MVFR', 'visibility ' + v + ' m'); }
    if (h != null) { if (h < 500) step('LIFR', 'ceiling ' + h + ' ft'); else if (h < 1000) step('IFR', 'ceiling ' + h + ' ft'); else if (h <= 3000) step('MVFR', 'ceiling ' + h + ' ft'); }
    const ph = (c.wx || []).filter((w) => /FG|BR|HZ|DZ|RA|SN|TS|FU|DU|SA|VA/.test(w)); const drv = ph.map((w) => w.replace(/^[+-]|VC/, '')).join(' ');
    return { cat, why: why.join(', '), cause: cat === 'VFR' ? '' : (ph.length && why.some((x) => /visib/.test(x)) ? drv : why[0]) };
  }
  /* ---------- decoding to plain language ---------- */
  const fmtW = (w) => !w ? null : (w.spd === 0 ? 'Calm' : (w.dir == null ? 'Variable direction' : 'From ' + pad(w.dir, 3) + '°') + ' at ' + w.spd + ' kt' + (w.gst ? ', gusting ' + w.gst + ' kt' : ''));
  const fmtV = (v) => v == null ? null : v >= 9999 ? '10 km or more' : v >= 5000 ? (v / 1000).toFixed(1).replace('.0', '') + ' km' : v + ' m';
  const fmtC = (k) => k.cov === 'VV' ? 'Vertical visibility ' + (k.ft ?? '?') + ' ft (sky obscured)' : COV[k.cov][0].toUpperCase() + COV[k.cov].slice(1) + ' at ' + (k.ft == null ? '?' : k.ft.toLocaleString('en-US')) + ' ft' + (k.type === 'CB' ? ' (cumulonimbus)' : k.type === 'TCU' ? ' (towering cumulus)' : '');
  function decode(m) {
    const L = []; const a = (k, v) => v != null && v !== '' && L.push([k, v]);
    a('Report', m.type + (m.cor ? ' (corrected)' : '') + (m.auto ? ', automatic' : '') + (m.icao ? ' for ' + m.icao : '') + (m.z ? ' at ' + m.z.slice(0, 2) + ' ' + m.z.slice(2, 4) + ':' + m.z.slice(4, 6) + 'Z' : ''));
    a('Wind', fmtW(m.wind) && fmtW(m.wind) + (m.wvar ? ', varying ' + pad(m.wvar[0], 3) + '° to ' + pad(m.wvar[1], 3) + '°' : ''));
    a('Visibility', m.cavok ? 'CAVOK — 10 km or more, no significant cloud or weather' : fmtV(m.vis));
    (m.rvr || []).forEach((r) => a('RVR runway ' + r.rwy, (r.pm === 'P' ? 'more than ' : r.pm === 'M' ? 'less than ' : '') + r.v + ' m' + (r.v2 ? ', varying to ' + r.v2 + ' m' : '') + ({ U: ', rising', D: ', falling', N: ', no change' }[r.tr] || '')));
    (m.wx || []).forEach((w) => a('Weather', wxText(w)));
    (m.clouds || []).forEach((k) => a('Cloud', fmtC(k))); if (!(m.clouds || []).length && !m.cavok) a('Cloud', m.clear ? 'No significant cloud / clear' : null);
    if (m.temp != null) a('Temperature / dew point', m.temp + '°C / ' + (m.dew ?? '—') + '°C');
    if (m.qnh != null) a('QNH', m.qnh + ' hPa' + (m.inhg ? ' (' + m.inhg.toFixed(2) + ' inHg)' : ' (' + (m.qnh / 33.8639).toFixed(2) + ' inHg)'));
    a('QFE', m.qfe ? m.qfe + ' hPa' : null);
    if (m.trend) { const t = m.trend; a('Trend', t.type === 'NOSIG' ? 'No significant change expected in the next 2 hours' : (t.type === 'BECMG' ? 'Becoming' : 'Temporarily') + ': ' + [fmtW(t.c.wind), t.c.cavok ? 'CAVOK' : fmtV(t.c.vis) && 'visibility ' + fmtV(t.c.vis), ...(t.c.wx || []).map(wxText), ...(t.c.clouds || []).map(fmtC)].filter(Boolean).join('; ') + (t.times.length ? ' (' + t.times.join(' ') + ')' : '')); }
    a('Remarks', m.rmk); return L;
  }
  /* ---------- TAF ---------- */
  function taf(raw, now = Date.now()) {
    const s = String(raw).replace(/=\s*$/, '').replace(/\s+/g, ' ').trim(), tk = s.split(' '), o = { raw: s, kind: 'TAF', groups: [] }; let i = 0;
    if (tk[i] === 'TAF') i++; if (tk[i] === 'AMD' || tk[i] === 'COR') o.kind = 'TAF ' + tk[i++]; if (/^[A-Z][A-Z0-9]{3}$/.test(tk[i])) o.icao = tk[i++];
    let m = (tk[i] || '').match(/^(\d{2})(\d{2})(\d{2})Z$/); if (m) { o.issued = dayMs(+m[1], +m[2], +m[3], now); i++; }
    m = (tk[i] || '').match(/^(\d{2})(\d{2})\/(\d{2})(\d{2})$/); if (!m) return Object.assign(o, { err: 'no validity period found' }); i++;
    const ref = o.issued ?? now, at = (d, h) => { const n = new Date(ref); let t = Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), +d, +h); if (t < ref - 5 * 864e5) t = Date.UTC(n.getUTCFullYear(), n.getUTCMonth() + 1, +d, +h); return t; };
    o.from = at(m[1], m[2]); o.to = at(m[3], m[4]); if (o.to <= o.from) o.to += 30 * 864e5; o.hours = Math.round((o.to - o.from) / 36e5); o.length = o.hours <= 9 ? '9 hr' : o.hours <= 24 ? '24 hr' : '30 hr';
    let g = { type: 'BASE', from: o.from, to: o.to, tokens: [] }; o.groups.push(g);
    for (; i < tk.length; i++) { const t = tk[i]; let q;
      if ((q = t.match(/^FM(\d{2})(\d{2})(\d{2})$/))) { const f = Date.UTC(new Date(o.from).getUTCFullYear(), new Date(o.from).getUTCMonth(), +q[1], +q[2], +q[3]); g = { type: 'FM', from: f < o.from - 864e5 ? f + 30 * 864e5 : f, to: o.to, tokens: [] }; o.groups.push(g); continue; }
      if (/^(BECMG|TEMPO)$/.test(t) || /^PROB(30|40)$/.test(t)) { let ty = t, nx = tk[i + 1]; if (/^PROB/.test(t) && nx === 'TEMPO') { ty = t + ' TEMPO'; i++; nx = tk[i + 1]; } const w = (nx || '').match(/^(\d{2})(\d{2})\/(\d{2})(\d{2})$/); if (w) { i++; g = { type: ty, from: at(w[1], w[2]), to: at(w[3], w[4]), tokens: [] }; o.groups.push(g); continue; } }
      if (/^(TX|TN)M?\d/.test(t)) continue; g.tokens.push(t); }
    o.groups.forEach((x) => { x.c = cond(x.tokens, {}); }); return o;
  }
  const WORST = ['VFR', 'MVFR', 'IFR', 'LIFR'], worse = (a, b) => WORST.indexOf(a) >= WORST.indexOf(b) ? a : b;
  const merge = (a, b) => { const c = JSON.parse(JSON.stringify(a)); for (const k of ['wind', 'vis', 'cavok']) if (b[k] != null) c[k] = b[k]; if (b.cavok) { c.clouds = []; c.wx = []; c.vis = 10000; } else if (b.cavok === undefined && (b.vis != null)) c.cavok = false; if (b.clouds && b.clouds.length) c.clouds = b.clouds; else if (b.clear) c.clouds = []; if (b.wx && b.wx.length) c.wx = b.wx; return c; };
  /* hourly timeline: prevailing (BASE/FM/BECMG applied from end of change period) + TEMPO/PROB overlay */
  function timeline(tf, from = tf.from, hours = null) {
    const n = hours ?? Math.round((tf.to - from) / 36e5), out = []; const base = tf.groups[0];
    for (let h = 0; h < n; h++) { const t0 = from + h * 36e5, t1 = t0 + 36e5; if (t0 < tf.from || t0 >= tf.to) continue;
      let c = base.c, label = 'BASE'; const fm = tf.groups.filter((g) => g.type === 'FM' || g.type === 'BECMG').sort((a, b) => (a.type === 'BECMG' ? a.to : a.from) - (b.type === 'BECMG' ? b.to : b.from));
      for (const g of fm) { const eff = g.type === 'BECMG' ? g.to : g.from; if (eff <= t0) { c = g.type === 'FM' ? merge({}, g.c) : merge(c, g.c); label = g.type; } }
      const pc = category(c) || { cat: 'VFR', cause: '' }; let ov = null;
      for (const g of tf.groups) if ((g.type === 'TEMPO' || /^PROB/.test(g.type)) && g.from < t1 && g.to > t0) { const oc = category(merge(c, g.c)); if (oc && WORST.indexOf(oc.cat) > WORST.indexOf((ov || pc).cat)) ov = { type: g.type, cat: oc.cat, cause: oc.cause, c: merge(c, g.c) }; }
      out.push({ t: t0, cat: pc.cat, cause: pc.cause, label, c, ov }); }
    return out;
  }
  /* ---------- runway / wind / tools ---------- */
  function runways(s) { const out = []; for (const part of String(s || '').split(/[\/,\s]+/).filter(Boolean)) { const m = part.match(/^(\d{1,2})([LCR]?)$/i); if (m) out.push({ id: pad(+m[1]) + m[2].toUpperCase(), hdg: (+m[1] % 36 || 36) * 10 }); else if (/^\d{3}$/.test(part)) out.push({ id: part + '°', hdg: +part % 360 }); }
    if (out.length === 1) { const h = (out[0].hdg + 180) % 360, n = Math.round(h / 10) % 36 || 36; out.push({ id: pad(n), hdg: n * 10 }); } return out; }
  const comp = (hdg, dir, spd) => { const a = (dir - hdg) * R; return { head: spd * Math.cos(a), cross: spd * Math.sin(a) }; };
  function bestRunway(rw, w) { if (!rw.length || !w || w.dir == null) return null; const sp = Math.max(w.spd || 0, w.gst || 0); let b = null; for (const r of rw) { const c = comp(r.hdg, w.dir, sp); if (!b || c.head > b.c.head) b = { r, c }; } return b; }
  const densityAlt = ({ elevFt, tempC, qnh }) => { const pa = elevFt + (1013.25 - qnh) * 27, isa = 15 - 0.00198 * pa; return { pa, isa, da: pa + 120 * (tempC - isa) }; };
  const jd = (ms) => ms / 864e5 + 2440587.5;
  function sun(lat, lon, ms = Date.now()) {
    const n = Math.ceil(jd(Date.UTC(new Date(ms).getUTCFullYear(), new Date(ms).getUTCMonth(), new Date(ms).getUTCDate(), 12)) - 2451545 + 0.0008), Js = n - lon / 360, M = (357.5291 + 0.98560028 * Js) % 360, C = 1.9148 * Math.sin(M * R) + 0.02 * Math.sin(2 * M * R) + 0.0003 * Math.sin(3 * M * R), L = (M + C + 180 + 102.9372) % 360;
    const Jt = 2451545 + Js + 0.0053 * Math.sin(M * R) - 0.0069 * Math.sin(2 * L * R), dec = Math.asin(Math.sin(L * R) * Math.sin(23.4397 * R)), cw = (Math.sin(-0.833 * R) - Math.sin(lat * R) * Math.sin(dec)) / (Math.cos(lat * R) * Math.cos(dec));
    if (cw > 1 || cw < -1) return null; const w = Math.acos(cw) / R, f = (J) => (J - 2440587.5) * 864e5; return { rise: f(Jt - w / 360), set: f(Jt + w / 360), noon: f(Jt) };
  }
  function moon(ms = Date.now()) { const S = 29.530588853, age = (((ms - Date.UTC(2000, 0, 6, 18, 14)) / 864e5) % S + S) % S, ill = (1 - Math.cos(2 * Math.PI * age / S)) / 2, nm = ['New moon', 'Waxing crescent', 'First quarter', 'Waxing gibbous', 'Full moon', 'Waning gibbous', 'Last quarter', 'Waning crescent'][Math.floor((age / S * 8 + .5) % 8)]; return { age, ill, name: nm }; }
  const wake = (mtow) => mtow == null ? null : mtow <= 7000 ? 'Light' : mtow < 136000 ? 'Medium' : 'Heavy';
  /* ---------- alerts ---------- */
  const DEF_TH = { vis: 1000, gust: 25, qnhDrop: 3, qnhHours: 3, ramp: 8, heat: 30 };
  function alerts(cur, prev, hist, th = DEF_TH) {
    const A = [], c = cur, ic = c.icao || '';
    if (c.vis != null && c.vis < th.vis) A.push({ id: 'vis', sev: 'red', text: ic + ' visibility ' + c.vis + ' m (below ' + th.vis + ' m)' });
    if (hasCB(c)) A.push({ id: 'cb', sev: 'red', text: ic + ': CB / thunderstorm activity in report' + ((c.wx || []).some((w) => /^VC/.test(w)) ? ' (in the vicinity)' : '') });
    if ((c.wx || []).some((w) => /TS/.test(w) && !/^VC/.test(w))) A.push({ id: 'ts', sev: 'red', text: ic + ': thunderstorm observed' });
    const g = c.wind && Math.max(c.wind.gst || 0, 0); if (g > th.gust) A.push({ id: 'gust', sev: 'amber', text: ic + ': wind gust ' + g + ' kt (above ' + th.gust + ' kt)' });
    if (c.qnh != null) { const old = (hist || []).filter((h) => h.qnh != null && h.t != null && c.t - h.t >= 36e5 && c.t - h.t <= th.qnhHours * 36e5).sort((a, b) => a.t - b.t)[0]; if (old && old.qnh - c.qnh >= th.qnhDrop) A.push({ id: 'qnh', sev: 'amber', text: ic + ': QNH fell ' + (old.qnh - c.qnh) + ' hPa in ' + ((c.t - old.t) / 36e5).toFixed(1) + ' h' }); }
    const cc = category(c), pc = prev ? category(prev) : null; if (cc && pc && cc.cat !== pc.cat) { const w = WORST.indexOf(cc.cat) > WORST.indexOf(pc.cat); A.push({ id: 'cat', sev: w ? (cc.cat === 'LIFR' || cc.cat === 'IFR' ? 'red' : 'amber') : 'info', text: ic + ' now ' + cc.cat + (w && cc.cause ? ' due to ' + cc.cause : '') + ' (was ' + pc.cat + ')' }); }
    if (c.type === 'SPECI') A.push({ id: 'speci', sev: 'info', text: ic + ': SPECI issued — weather changed suddenly' });
    return A;
  }
  /* SPECI-style change detection between two consecutive reports */
  const suddenChange = (a, b) => { if (!a || !b) return []; const r = [], ca = category(a), cb = category(b); if (ca && cb && ca.cat !== cb.cat) r.push('category ' + ca.cat + ' → ' + cb.cat);
    if (a.wind && b.wind && (Math.abs((a.wind.spd || 0) - (b.wind.spd || 0)) >= 10 || ((a.wind.gst || 0) < 25 && (b.wind.gst || 0) >= 25))) r.push('wind change'); if (!hasTS(a) && hasTS(b)) r.push('thunderstorm began'); if (a.vis != null && b.vis != null && ((a.vis >= 1500 && b.vis < 1500) || (a.vis >= 800 && b.vis < 800))) r.push('visibility dropped'); return r; };
  /* ---------- advice engine ---------- */
  const SEV = { red: 3, amber: 2, info: 1 };
  function advise({ ac, m, tf, stn, rwy, etd, extra = {}, th = DEF_TH, sigmets = 0 }) {
    const P = [], T = [], D = [], G = [], why = [], add = (arr, sev, text) => arr.push({ sev, text }), cat = category(m), tName = ac ? ac.type : null, w = m.wind, sp = w ? Math.max(w.spd || 0, w.gst || 0) : 0, T0 = m.temp;
    const rw = runways(rwy || (stn && stn.rwy)), br = bestRunway(rw, w), pre = (ac && ac.type ? ac.type : 'aircraft');
    if (cat) add(P, cat.cat === 'VFR' ? 'info' : cat.cat === 'MVFR' ? 'amber' : 'red', 'Flight category ' + cat.cat + (cat.cause ? ' (' + cat.cause + ')' : '') + '.');
    if (br) { const xw = Math.abs(br.c.cross), tail = Math.max(0, -br.c.head); add(P, 'info', 'Best runway for this wind: RWY ' + br.r.id + ' — headwind ' + Math.max(0, Math.round(br.c.head)) + ' kt, crosswind ' + Math.round(xw) + ' kt' + (tail > 0 ? ', tailwind ' + Math.round(tail) + ' kt' : '') + ' (uses gust value ' + sp + ' kt).');
      if (ac) { if (ac.xw > 0) { const p = Math.round(100 * xw / ac.xw); const s = p >= 100 ? 'red' : p >= 75 ? 'amber' : 'info'; add(P, s, 'Crosswind ' + Math.round(xw) + ' kt = ' + p + '% of your configured ' + ac.xw + ' kt limit for ' + pre + '.'); if (s === 'red') why.push('Crosswind ' + Math.round(xw) + ' kt exceeds your ' + ac.xw + ' kt limit'); else if (s === 'amber') why.push('Crosswind at ' + p + '% of limit'); } else add(P, 'info', 'Crosswind limit not set for ' + pre + ' — add it on the Aircraft tab.');
        if (ac.tw > 0 && tail > 0) { const s = tail > ac.tw ? 'red' : tail >= ac.tw * .75 ? 'amber' : 'info'; add(P, s, 'Tailwind ' + Math.round(tail) + ' kt vs your configured limit ' + ac.tw + ' kt (best runway).'); if (s === 'red') why.push('Tailwind ' + Math.round(tail) + ' kt exceeds your ' + ac.tw + ' kt limit'); } } }
    else if (w && w.dir == null && w.spd) add(P, 'info', 'Variable wind direction — runway components not calculated.');
    if (w && w.gst && w.gst - w.spd >= 10) add(P, 'amber', 'Gusty: spread ' + (w.gst - w.spd) + ' kt — turbulence / wind-shear potential on approach.');
    const cb = hasCB(m), ts = (m.wx || []).some((x) => /TS/.test(x));
    if (cb || ts) { if (ac && ac.cat === 'Light') { add(P, 'red', 'CB / thunderstorm reported — severe turbulence, icing and hail risk for light aircraft.'); why.push('CB / thunderstorm reported (light aircraft)'); } else { add(P, 'amber', 'CB / thunderstorm reported — expect turbulence, lightning and wind shear; follow your operator\'s procedures.'); why.push('CB / thunderstorm reported'); } }
    if (ac && ac.cat === 'Light' && cat && (cat.cat === 'IFR' || cat.cat === 'LIFR')) { add(P, 'red', 'Conditions are ' + cat.cat + ' — below VFR minima for VFR-only operations.'); why.push(cat.cat + ' conditions (VFR light aircraft)'); }
    if (ac && ac.visMin > 0 && m.vis != null && m.vis < ac.visMin) { add(P, 'red', 'Visibility ' + m.vis + ' m is below your configured minimum ' + ac.visMin + ' m.'); why.push('Visibility below your ' + ac.visMin + ' m minimum'); }
    if (ac && ac.ceilMin > 0 && ceiling(m) != null && ceiling(m) < ac.ceilMin) { add(P, 'red', 'Ceiling ' + ceiling(m) + ' ft is below your configured minimum ' + ac.ceilMin + ' ft.'); why.push('Ceiling below your ' + ac.ceilMin + ' ft minimum'); }
    if (ac && ac.tmax > 0 && T0 != null && T0 >= ac.tmax - 5) { const s = T0 >= ac.tmax ? 'red' : 'amber'; add(P, s, 'Temperature ' + T0 + '°C vs your configured maximum ' + ac.tmax + '°C.'); if (s === 'red') why.push('Temperature above your configured maximum'); }
    if (ac && /no known|non/i.test(ac.icing || '') && T0 != null && T0 <= 3 && ((m.clouds || []).length || (m.wx || []).length)) add(P, 'amber', 'Surface temperature ' + T0 + '°C with cloud/precipitation: icing possible for an aircraft without known-icing approval (conditions aloft not available here).');
    add(P, 'info', 'Fuel / winds-aloft advice needs upper-wind data, which this version does not load.');
    // turnaround
    const lightKm = extra.lightningKm;
    if (lightKm != null && lightKm <= th.ramp) add(T, 'red', 'Lightning ' + lightKm + ' km away (≤ ' + th.ramp + ' km): stop refuelling and ramp operations per your local procedure.'); else if (ts) add(T, 'red', 'Thunderstorm in report: treat lightning as within the ramp-stop radius until confirmed (enter measured lightning distance on the Tools tab).');
    else if ((m.wx || []).some((x) => /^VC/.test(x))) add(T, 'amber', 'Weather in the vicinity: monitor lightning distance.');
    if (w && w.gst > th.gust) add(T, 'amber', 'Gusts ' + w.gst + ' kt (> ' + th.gust + ' kt): chock all GSE, secure ULDs, delay open-door catering.');
    if ((m.wx || []).some((x) => /\+?RA|SH|DZ/.test(x))) add(T, (m.wx || []).some((x) => /^\+/.test(x)) ? 'amber' : 'info', 'Rain: slippery surfaces' + ((m.wx || []).some((x) => /^\+/.test(x)) ? '; heavy rain — allow about 10 min extra for turnaround' : '') + '.');
    if (T0 != null && T0 > th.heat) add(T, 'amber', 'Temperature ' + T0 + '°C (> ' + th.heat + '°C): heat-stress risk for ramp staff — hydration and rest breaks.');
    if (m.vis != null && m.vis < th.vis) add(T, 'amber', 'Low visibility (' + m.vis + ' m): low-visibility ramp procedures, marshaller and vehicle lights.');
    // dispatch
    if (tf && !tf.err) { const t0 = etd != null ? etd : Date.now(), win = timeline(tf, t0 - 36e5, 4).filter(Boolean); if (!win.length) add(D, 'info', 'The loaded TAF (' + hhz(tf.from) + '–' + hhz(tf.to) + ') does not cover the ETD window — it is expired or not yet valid; load a current TAF.'); else { const bad = win.filter((x) => ['IFR', 'LIFR'].includes(x.ov ? worse(x.cat, x.ov.cat) : x.cat));
      if (etd != null) { const at = win.find((x) => etd >= x.t && etd < x.t + 36e5); if (at) add(D, ['IFR', 'LIFR'].includes(at.cat) ? 'red' : at.cat === 'MVFR' ? 'amber' : 'info', 'TAF at ' + hhz(etd) + ': prevailing ' + at.cat + (at.cause ? ' (' + at.cause + ')' : '') + (at.ov ? '; ' + at.ov.type + ' ' + at.ov.cat + (at.ov.cause ? ' (' + at.ov.cause + ')' : '') : '') + '.'); }
      if (bad.length) add(D, 'amber', 'TAF shows IFR/LIFR conditions in the window ' + hhz(win[0].t) + '–' + hhz(win[win.length - 1].t + 36e5) + ': consider delay or alternate planning.'); else add(D, 'info', 'No IFR/LIFR forecast in the ETD window (' + hhz(win[0].t) + '–' + hhz(win[win.length - 1].t + 36e5) + ').'); } }
    else add(D, 'info', 'No TAF loaded — dispatch outlook unavailable.');
    if (sigmets) add(D, 'amber', sigmets + ' SIGMET(s) listed for your FIR(s) — read them before flight planning.');
    // ground
    if (T0 != null && T0 <= 2 && (m.wx || []).some((x) => /RA|DZ|SN|FZ/.test(x))) add(G, 'amber', 'Temperature ' + T0 + '°C with precipitation: de-icing may be required.');
    if (cb || ts) add(G, 'red', 'Thunderstorm procedure: trigger your station\'s thunderstorm / lightning-warning procedure.');
    if (!G.length) add(G, 'info', 'No ground-handling triggers in this report.');
    const lv = (arr) => arr.some((x) => x.sev === 'red') ? 'red' : arr.some((x) => x.sev === 'amber') ? 'amber' : 'green', lvl = lv([...P, ...D]), ramp = lv([...T, ...G]);
    const head = { red: 'ADVISORY — EXCEEDS YOUR CONFIGURED LIMITS / CONDITIONS', amber: 'CAUTION — REVIEW BEFORE OPERATING', green: 'NO CONFIGURED LIMIT EXCEEDED' }[lvl];
    return { level: lvl, rampLevel: ramp, head: head + (tName ? ' · ' + tName : ''), why, P, T, D, G, rwy: br };
  }
  const hhz = (ms) => pad(new Date(ms).getUTCHours()) + 'Z';
  /* split AWC-style raw text into report strings */
  function split(txt) { const out = []; let cur = ''; for (const ln of String(txt).split(/\r?\n/)) { const l = ln.trim(); if (!l) continue; if (/^(METAR|SPECI|TAF)\b/.test(l) || /^[A-Z]{4}\s+\d{6}Z\b/.test(l)) { if (cur) out.push(cur); cur = l; } else cur += ' ' + l; if (/=$/.test(cur)) { out.push(cur); cur = ''; } } if (cur) out.push(cur); return out; }
  return { metar, taf, decode, category, ceiling, hasTS, hasCB, timeline, runways, comp, bestRunway, densityAlt, sun, moon, wake, alerts, suddenChange, advise, split, wxText, cond, DEF_TH, WORST, worse, hhz };
})();
if (typeof module !== 'undefined') module.exports = Ops;
