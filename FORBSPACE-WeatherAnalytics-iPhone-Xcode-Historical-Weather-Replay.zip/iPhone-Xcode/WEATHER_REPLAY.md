# FORBSPACE Historical Weather Replay

## Added
A dependency-free WebGL2 immersive historical replay integrated into the existing offline iPhone/iPad web app.

### Runtime modules
- `weather-replay.js`
  - `WeatherConditionMapper`
  - `WeatherInterpolationEngine`
  - `PerformanceManager`
  - `WebGLWeatherRenderer`
  - `HistoricalWeatherReplay`
- `weather-replay.css`
- `index.html` adapter exposing existing normalized observations
- `sw.js` cache updated to include the new assets

## Integration
The existing analytics state is not replaced. `index.html` exposes:
- `window.ForBspaceReplaySource()` — adapter over `S.recs`
- `window.ForBspaceReplaySelectedAirport()` — current airport selection

The replay opens from a new **Weather Replay** navigation button. It is an overlay, so existing analytics pages, routing, filters and exports remain intact.

## Data normalization
The replay accepts the requested interface:
`time, temperature, apparentTemperature, humidity, precipitation, rain, snowfall, cloudCover, cloudCoverLow, cloudCoverMid, cloudCoverHigh, windSpeed, windGusts, windDirection, pressure, visibility, weatherCode, sunrise, sunset, latitude, longitude, timezone`.

The existing app's fields (`T`, `rh`, `pr`, `ws`, `gu`, `wd`, `p`, `vis`, `raw`) are mapped automatically.

No extreme condition is invented when observations are incomplete.

## WMO mapping
| Codes | Visual state | Intensity |
|---|---|---|
| 0 | Clear sky | 0 |
| 1 | Mainly clear | 0.18 |
| 2 | Partly cloudy | 0.38 |
| 3 | Overcast | 0.80 |
| 45,48 | Fog / rime fog | 0.70–0.85 |
| 51,53,55 | Drizzle | 0.25–0.70 |
| 56,57,66,67 | Freezing/mixed precipitation | 0.40–0.85 |
| 61,63 | Rain | 0.35–0.60 |
| 65,82 | Heavy/violent rain | 0.90–1.00 |
| 71,73,75,77 | Snow | 0.30–0.90 |
| 80,81 | Rain showers | 0.45–0.65 |
| 85,86 | Snow showers | 0.45–0.90 |
| 95,96,99 | Thunderstorm | 0.82–1.00 |

If WMO code is unavailable, METAR weather tokens are used conservatively; otherwise precipitation, visibility and cloud cover can infer only broad conditions.

## Interpolation
Continuous variables are linearly interpolated between adjacent observations:
temperature, humidity, precipitation, rain, snowfall, cloud layers, wind speed/gusts, pressure and visibility.

Wind direction uses the shortest circular angular path, preventing a false 359° → 1° rotation.

Weather condition and WMO code use the nearest observation rather than inventing a new code. Visual intensity is smoothed by the renderer.

## Confidence
- **High**: weather code, precipitation, cloud cover, wind and visibility are present.
- **Medium**: some fields are missing.
- **Low**: condition is primarily inferred from limited fields.

## Performance
- WebGL2 fullscreen procedural shader
- No remote assets/CDNs
- Adaptive DPR
- Low/Balanced/High/Ultra quality
- Reduced-motion mode disables animated lightning and motion-heavy effects
- Service worker cache includes replay assets
- Existing app remains usable if WebGL2 is unavailable

## Accessibility
- Keyboard: Space play/pause, Left/Right step, Escape close
- Reduced motion follows system preference and can be explicitly enabled
- Lightning is suppressed in reduced-motion mode
- Audio is off by default and only initializes after user action
- High contrast is inherited from the existing application; clean analytics mode reduces cinematic UI

## Important limitation
The supplied app currently normalizes METAR/historical observations into a compact schema. It does not contain all requested fields (notably separate low/mid/high cloud cover, WMO weather code, snowfall and exact sunrise/sunset) in its current normalization layer. The replay therefore consumes those fields whenever supplied by a future dataset, while safely degrading for the current dataset.

This is a visualization of historical observations, not an operational weather product or dispatch clearance.
