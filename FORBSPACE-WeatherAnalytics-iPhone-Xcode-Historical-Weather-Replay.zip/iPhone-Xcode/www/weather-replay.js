
/*
 * FORBSPACE Historical Weather Replay
 * Dependency-free WebGL2 weather renderer for the bundled/offline iOS web app.
 * The renderer is intentionally procedural: no remote textures, fonts, CDNs or audio files.
 */
(()=>{"use strict";
const TAU=Math.PI*2, clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), lerp=(a,b,t)=>a+(b-a)*t,
  smooth=(a,b,t)=>{t=clamp((t-a)/(b-a),0,1);return t*t*(3-2*t)},
  rad=d=>d*Math.PI/180, fmt=n=>n==null?"—":Number(n).toFixed(n%1?1:0);

const WMO={
  0:["Clear sky","clear",0],1:["Mainly clear","clear",.18],2:["Partly cloudy","partly",.38],3:["Overcast","overcast",.8],
  45:["Fog","fog",.7],48:["Depositing rime fog","fog",.85],51:["Light drizzle","drizzle",.25],53:["Drizzle","drizzle",.45],55:["Heavy drizzle","drizzle",.7],
  56:["Freezing drizzle","mixed",.4],57:["Heavy freezing drizzle","mixed",.7],61:["Light rain","rain",.35],63:["Rain","rain",.6],65:["Heavy rain","heavy-rain",.9],
  66:["Freezing rain","mixed",.55],67:["Heavy freezing rain","mixed",.85],71:["Light snow","snow",.3],73:["Snow","snow",.6],75:["Heavy snow","snow",.9],
  77:["Snow grains","snow",.5],80:["Light rain showers","rain",.45],81:["Rain showers","rain",.65],82:["Violent rain showers","heavy-rain",1],
  85:["Light snow showers","snow",.45],86:["Heavy snow showers","snow",.9],95:["Thunderstorm","thunderstorm",.82],
  96:["Thunderstorm with hail","thunderstorm",.92],99:["Thunderstorm with heavy hail","thunderstorm",1]
};
const CODE_ALIASES={TS:"thunderstorm",CB:"thunderstorm",RA:"rain",DZ:"drizzle",SN:"snow",SG:"snow",PL:"mixed",FZRA:"mixed",FG:"fog",BR:"fog",HZ:"haze",DU:"dust",SA:"dust",FU:"smoke"};

class WeatherConditionMapper{
  map(r){
    const code=r.weatherCode!=null?Number(r.weatherCode):null;
    if(code!=null&&WMO[code]){const x=WMO[code];return {name:x[0],state:x[1],intensity:x[2],source:"WMO"}}
    const raw=String(r.rawWeather||r.weather||"").toUpperCase();
    for(const k of Object.keys(CODE_ALIASES))if(raw.includes(k))return {name:k,state:CODE_ALIASES[k],intensity:.55,source:"METAR/text"};
    const p=r.precipitation??r.rain??0,t=r.temperature;
    if(p>0.1){if(t!=null&&t<=0)return {name:"Snow / mixed precipitation",state:"snow",intensity:clamp(p/8,.25,1),source:"inferred"};return {name:"Rain",state:p>=6?"heavy-rain":"rain",intensity:clamp(p/8,.2,1),source:"inferred"}}
    if(r.visibility!=null&&r.visibility<1)return {name:"Fog / mist",state:"fog",intensity:clamp(1-r.visibility,0,.95),source:"inferred"};
    if(r.visibility!=null&&r.visibility<6)return {name:"Haze",state:"haze",intensity:clamp((6-r.visibility)/6,.1,.75),source:"inferred"};
    const c=r.cloudCover??null;if(c!=null)return {name:c>=.85?"Overcast":c>=.45?"Partly cloudy":"Clear sky",state:c>=.85?"overcast":c>=.45?"partly":"clear",intensity:c};
    return {name:"Historical condition",state:"clear",intensity:.15,source:"limited data"};
  }
}
class WeatherInterpolationEngine{
  constructor(mapper=new WeatherConditionMapper){this.mapper=mapper}
  norm(r){
    const n={...r}; n.time=new Date(r.time).getTime();
    n.temperature=n.temperature??r.T;n.apparentTemperature=n.apparentTemperature??n.temperature;
    n.humidity=n.humidity??r.rh;n.precipitation=n.precipitation??r.pr??0;n.rain=n.rain??r.rain??(n.precipitation||0);
    n.snowfall=n.snowfall??r.snowfall??0;n.cloudCover=n.cloudCover??r.cloudCover??(r.cloud!=null?r.cloud/100:null);
    n.cloudCoverLow=n.cloudCoverLow??r.cloudCoverLow;n.cloudCoverMid=n.cloudCoverMid??r.cloudCoverMid;n.cloudCoverHigh=n.cloudCoverHigh??r.cloudCoverHigh;
    n.windSpeed=n.windSpeed??r.ws??0;n.windGusts=n.windGusts??r.gu??n.windSpeed;n.windDirection=n.windDirection??r.wd??0;
    n.pressure=n.pressure??r.p;n.visibility=n.visibility??r.vis;n.weatherCode=n.weatherCode??r.weatherCode;
    n.latitude=n.latitude??r.lat;n.longitude=n.longitude??r.lon;n.timezone=n.timezone||r.timezone;
    if(n.cloudCover!=null&&n.cloudCover>1)n.cloudCover/=100;
    for(const k of ["cloudCoverLow","cloudCoverMid","cloudCoverHigh"])if(n[k]!=null&&n[k]>1)n[k]/=100;
    n.condition=this.mapper.map(n);return n
  }
  sort(rows){return rows.map(x=>this.norm(x)).filter(x=>Number.isFinite(x.time)).sort((a,b)=>a.time-b.time)}
  between(a,b,t){
    if(!a)return b;if(!b)return a;if(b.time===a.time)return {...a};
    const q=clamp((t-a.time)/(b.time-a.time),0,1),o={time:t};
    const numeric=["temperature","apparentTemperature","humidity","precipitation","rain","snowfall","cloudCover","cloudCoverLow","cloudCoverMid","cloudCoverHigh","windSpeed","windGusts","pressure","visibility"];
    for(const k of numeric)o[k]=a[k]==null?b[k]:b[k]==null?a[k]:lerp(a[k],b[k],q);
    const da=a.windDirection??0,db=b.windDirection??da,d=((db-da+540)%360)-180;o.windDirection=(da+d*q+360)%360;
    o.weatherCode=q<.5?a.weatherCode:b.weatherCode;o.latitude=a.latitude??b.latitude;o.longitude=a.longitude??b.longitude;o.timezone=a.timezone||b.timezone;
    o.condition=this.mapper.map(o);return o
  }
  at(rows,t){if(!rows.length)return null;let hi=rows.findIndex(x=>x.time>=t);if(hi<0)return rows.at(-1);if(hi===0)return rows[0];return this.between(rows[hi-1],rows[hi],t)}
}
class PerformanceManager{
  constructor(){this.quality=localStorage.getItem("wr-quality")||"balanced";this.dpr=1}
  choose(){const q={low:.7,balanced:1,high:1.35,ultra:1.7}[this.quality]||1;this.dpr=Math.min(devicePixelRatio||1,1.6)*q;return q}
  set(q){this.quality=q;localStorage.setItem("wr-quality",q)}
}
class WebGLWeatherRenderer{
  constructor(canvas){this.c=canvas;this.gl=canvas.getContext("webgl2",{alpha:false,antialias:false,powerPreference:"high-performance"});if(!this.gl)throw Error("WebGL2 is not available on this device.");
    this.pm=new PerformanceManager();this.q=this.pm.choose();this.t0=performance.now();this.state={};this.camera="dashboard";this.reduced=matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.program=this.makeProgram();this.buf=this.gl.createBuffer();this.gl.bindBuffer(this.gl.ARRAY_BUFFER,this.buf);this.gl.bufferData(this.gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),this.gl.STATIC_DRAW);
    this.a=this.gl.getAttribLocation(this.program,"a");this.u={};["uTime","uSun","uCloud","uLow","uMid","uHigh","uRain","uSnow","uWind","uDir","uVis","uHumidity","uTemp","uPressure","uState","uLightning","uCamera","uResolution"].forEach(k=>this.u[k]=this.gl.getUniformLocation(this.program,k));
    addEventListener("resize",()=>this.resize(),{passive:true});this.resize();this.loop();
  }
  makeProgram(){
    const g=this.gl,vs=`#version 300 es
      in vec2 a;out vec2 uv;void main(){uv=a*.5+.5;gl_Position=vec4(a,0.,1.);}`;
    const fs=`#version 300 es
      precision highp float;in vec2 uv;out vec4 o;
      uniform float uTime,uSun,uCloud,uLow,uMid,uHigh,uRain,uSnow,uWind,uDir,uVis,uHumidity,uTemp,uPressure,uState,uLightning,uCamera;uniform vec2 uResolution;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
      float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.02+13.1;a*=.5;}return v;}
      vec3 sky(vec2 p){
        float elev=clamp(uSun,0.,1.);vec3 day=mix(vec3(.025,.10,.28),vec3(.36,.67,1.),p.y);
        vec3 night=mix(vec3(.005,.008,.025),vec3(.025,.06,.15),p.y);vec3 col=mix(night,day,elev);
        float storm=step(.7,uState);col=mix(col,vec3(.07,.09,.12),storm*.55);
        float cloudNoise=fbm(vec2(p.x*2.2+uTime*.006*uWind,p.y*2.5));
        float cov=smoothstep(.35,.85,cloudNoise)*uCloud;
        col=mix(col,vec3(.72,.77,.83),cov*.48);
        col*=mix(1.,.72,uCloud);
        float haze=clamp((1./max(uVis,.25))*.35+uHumidity*.12,0.,.65);col=mix(col,vec3(.66,.70,.73),haze);
        return col;
      }
      void main(){
        vec2 p=uv;float t=uTime*.001;vec3 col=sky(p);
        float horizon=smoothstep(.46,.56,p.y);
        // Perspective ground: the lower half becomes a simple 3D ground plane with depth fade.
        vec2 gp=(p-.5)*vec2(2.,1.);float grid=exp(-abs(fract((gp.x+t*uWind*.002*cos(radians(uDir)))*7.)-.5)*18.);
        float wet=clamp(uRain*.12,0.,.3);vec3 ground=mix(vec3(.10,.18,.13),vec3(.08,.10,.12),wet);
        col=mix(ground,col,horizon);
        col+=grid*.025*(1.-horizon)*wet;
        // Layered cloud banks: high wisps, mid stratus, low dark base.
        float drift=cos(radians(uDir))*t*uWind*.008;
        float n1=fbm(vec2(p.x*2.4+drift,p.y*1.7));float n2=fbm(vec2(p.x*4.-drift*.6,p.y*2.7+uTime*.0003*uWind));
        float high=smoothstep(.52,.8,n1)*uHigh*.22,mid=smoothstep(.45,.78,n2)*uMid*.34,low=smoothstep(.4,.7,fbm(p*3.+drift))*uLow*.48;
        col=mix(col,vec3(.83,.87,.92),high);col=mix(col,vec3(.58,.64,.72),mid);col=mix(col,vec3(.24,.29,.36),low);
        // Sun glow and twilight band.
        float sunx=.5+.42*cos(t*.01),suny=.52+.38*sin(t*.01);float sun=exp(-distance(p,vec2(sunx,suny))*45.)*uSun*(1.-uCloud);
        col+=vec3(1.,.72,.36)*sun*.65;
        // Stars at night.
        float stars=(1.-uSun)*(1.-uCloud)*step(.55,noise(p*140.));
        col+=vec3(1.)*stars*.35;
        // Rain streak field.
        float rx=fract(p.x*210.+t*uWind*.4*cos(radians(uDir))),ry=fract(p.y*90.+t*(5.+uRain*12.) );
        float drops=smoothstep(.035,.0,abs(rx-.5))*smoothstep(.6,.0,abs(ry-.5))*uRain;
        col=mix(col,vec3(.62,.75,.88),drops*.55);
        // Snow: slower, wider flakes.
        float sn=step(.94,noise(p*95.+vec2(t*.5, -t*.8)))*uSnow;col+=vec3(.9,.95,1.)*sn;
        // Haze/dust.
        float dust=smoothstep(.45,.8,fbm(p*5.+vec2(drift,0)))*max(0.,uState-1.5)*.12;col=mix(col,vec3(.62,.48,.28),dust);
        col*=1.-uPressure*.08;
        col+=uLightning*vec3(1.0,.95,.78);
        o=vec4(pow(max(col,0.),vec3(.92)),1.);
      }`;
    const compile=(type,src)=>{const s=g.createShader(type);g.shaderSource(s,src);g.compileShader(s);if(!g.getShaderParameter(s,g.COMPILE_STATUS))throw Error(g.getShaderInfoLog(s));return s};
    const p=g.createProgram();g.attachShader(p,compile(g.VERTEX_SHADER,vs));g.attachShader(p,compile(g.FRAGMENT_SHADER,fs));g.linkProgram(p);if(!g.getProgramParameter(p,g.LINK_STATUS))throw Error(g.getProgramInfoLog(p));return p
  }
  resize(){const r=this.pm.dpr;this.c.width=Math.max(1,innerWidth*r);this.c.height=Math.max(1,innerHeight*r);this.gl.viewport(0,0,this.c.width,this.c.height)}
  setState(s){this.state=s}
  frame(now){const g=this.gl,s=this.state||{};g.useProgram(this.program);g.bindBuffer(g.ARRAY_BUFFER,this.buf);const a=g.getAttribLocation(this.program,"a");g.enableVertexAttribArray(a);g.vertexAttribPointer(a,2,g.FLOAT,false,0,0);
    const c=s.condition||{};const sun=s.sunFactor??.5, cloud=s.cloudCover??0, rain=s.rain??0, snow=s.snowfall??0, vis=s.visibility??20;
    g.uniform1f(this.u.uTime,now);g.uniform1f(this.u.uSun,sun);g.uniform1f(this.u.uCloud,cloud);g.uniform1f(this.u.uLow,s.cloudLow??cloud);g.uniform1f(this.u.uMid,s.cloudMid??cloud);g.uniform1f(this.u.uHigh,s.cloudHigh??cloud);
    g.uniform1f(this.u.uRain,clamp(rain/12,0,1));g.uniform1f(this.u.uSnow,clamp(snow/8,0,1));g.uniform1f(this.u.uWind,clamp((s.windSpeed||0)/50,0,2));g.uniform1f(this.u.uDir,s.windDirection||0);g.uniform1f(this.u.uVis,clamp(vis/20,.25,1));g.uniform1f(this.u.uHumidity,clamp((s.humidity||0)/100,0,1));g.uniform1f(this.u.uTemp,clamp(((s.temperature??20)+30)/80,0,1));g.uniform1f(this.u.uPressure,clamp(((s.pressure??1013)-970)/100,0,1));g.uniform1f(this.u.uState,c.state==="thunderstorm"?.9:c.state==="fog"?.25:c.state==="snow"?.12:c.state==="dust"?.2:0);g.uniform1f(this.u.uLightning,s.lightning||0);g.uniform1f(this.u.uCamera,this.camera==="ground"?-.15:this.camera==="overview"?.15:0);g.uniform2f(this.u.uResolution,this.c.width,this.c.height);g.drawArrays(g.TRIANGLE_STRIP,0,4)}
  loop(){requestAnimationFrame(n=>{this.frame(n);this.loop()})}
}
class HistoricalWeatherReplay{
  constructor(){
    this.engine=new WeatherInterpolationEngine();this.renderer=null;this.rows=[];this.idx=0;this.playing=false;this.speed=1;this.timer=null;this.range=[0,0];this.lastTime=0;this.events=[];this.confidence="low";this.audio=null;this.flash=0;
    this.mount();this.observeNav();this.load()
  }
  mount(){
    if(document.getElementById("weatherReplayRoot"))return;
    const root=document.createElement("section");root.id="weatherReplayRoot";root.setAttribute("aria-label","Historical Weather Replay");
    root.innerHTML=`<canvas class="wr-canvas"></canvas><div class="wr-ui">
      <div class="wr-top"><div class="wr-card wr-title"><b>Historical Weather Replay</b><small id="wrLoc">Historical data visualization</small><div style="margin-top:5px"><span id="wrConfidence" class="wr-confidence low">Data Confidence: Low</span></div></div>
      <div class="wr-actions"><button class="wr-btn wr-close" id="wrClose" aria-label="Close replay">×</button></div></div>
      <div class="wr-bottom"><div class="wr-card wr-stats"><div class="wr-stat"><span>Local time</span><b id="wrTime">—</b></div><div class="wr-stat"><span>Condition</span><b id="wrCond">—</b></div><div class="wr-stat"><span>Temp</span><b id="wrTemp">—</b></div><div class="wr-stat"><span>Rain</span><b id="wrRain">—</b></div><div class="wr-stat"><span>Wind</span><b id="wrWind">—</b></div><div class="wr-stat"><span>Humidity</span><b id="wrHum">—</b></div><div class="wr-stat"><span>Visibility</span><b id="wrVis">—</b></div></div>
      <div class="wr-card wr-timeline"><div class="wr-track"><button class="wr-btn" id="wrPlay" aria-label="Play replay">▶</button><button class="wr-btn" id="wrBack">−1h</button><button class="wr-btn" id="wrNext">+1h</button><input id="wrRange" type="range" min="0" max="0" value="0" aria-label="Historical replay timeline"><span class="wr-time" id="wrRangeLabel">—</span></div>
      <div class="wr-events" id="wrEvents"></div><div class="wr-controls"><select id="wrLocation" class="wr-select" aria-label="Replay location"></select><select id="wrSpeed" class="wr-select" aria-label="Replay speed"><option value="1">1×</option><option value="2">2×</option><option value="5">5×</option><option value="10">10×</option><option value="30">30×</option><option value="60">60×</option></select>
      <select id="wrCamera" class="wr-select" aria-label="Camera mode"><option value="dashboard">Dashboard view</option><option value="ground">Ground observer</option><option value="overview">Elevated overview</option><option value="cinematic">Cinematic orbit</option><option value="free">Free look</option></select>
      <select id="wrQuality" class="wr-select" aria-label="Render quality"><option value="low">Low</option><option value="balanced">Balanced</option><option value="high">High</option><option value="ultra">Ultra</option></select>
      <button class="wr-btn" id="wrMotion" aria-pressed="false">Reduced motion</button><button class="wr-btn" id="wrAudio" aria-pressed="false">Audio off</button><button class="wr-btn" id="wrClean" aria-pressed="false">Clean analytics</button></div>
      <div class="wr-help">Procedural 3D scene driven by historical observations. Missing fields are not invented. Press Space to play/pause; Esc to close.</div></div></div></div>`;
    document.body.appendChild(root);this.root=root;
    try{this.renderer=new WebGLWeatherRenderer(root.querySelector("canvas"))}catch(e){root.querySelector(".wr-help").textContent="3D renderer unavailable: "+e.message+" — the timeline and historical data remain available.";root.dataset.noWebgl="1"}
    this.bind()
  }
  observeNav(){const nav=document.getElementById("nav");if(!nav)return;const add=()=>{if(nav.querySelector("#replayTab"))return;const b=document.createElement("button");b.id="replayTab";b.type="button";b.textContent="Weather Replay";b.title="Open Historical Weather Replay";nav.appendChild(b)};new MutationObserver(add).observe(nav,{childList:true});add();nav.addEventListener("click",e=>{if(e.target.closest("#replayTab")){e.preventDefault();e.stopImmediatePropagation();this.open()}})
  }
  source(){try{if(window.ForBspaceReplaySource){const r=window.ForBspaceReplaySource();if(Array.isArray(r)&&r.length)return r}}catch(e){}return Array.isArray(window.FORBSPACE_WEATHER_REPLAY_DATA)?window.FORBSPACE_WEATHER_REPLAY_DATA:[]}
  load(){const all=this.engine.sort(this.source());const names=[...new Set(all.map(r=>r.ap||r.airport||"UNKNOWN"))].sort();const sel=this.root.querySelector("#wrLocation");
if(sel){sel.innerHTML=names.map(n=>`<option value="${String(n).replace(/"/g,"&quot;")}">${n}</option>`).join("");if(window.ForBspaceReplaySelectedAirport)sel.value=window.ForBspaceReplaySelectedAirport()||names[0]||"";this.location=sel.value}
this.rows=this.engine.sort(all.filter(r=>!this.location||(r.ap||r.airport||"UNKNOWN")===this.location));if(!this.rows.length)this.rows=all;
if(!this.rows.length){this.renderEmpty();return}this.range=[this.rows[0].time,this.rows.at(-1).time];this.idx=0;this.events=this.detectEvents();this.update()}
  confidence(r){const keys=["weatherCode","precipitation","cloudCover","windSpeed","visibility"],n=keys.filter(k=>r[k]!=null).length;return n>=5?"high":n>=2?"medium":"low"}
  detectEvents(){const e=[];for(let i=1;i<this.rows.length;i++){const a=this.rows[i-1],b=this.rows[i],c=b.condition.state;if(c==="thunderstorm"&&a.condition.state!=="thunderstorm")e.push([b.time,"Thunderstorm developing"]);if((b.rain||0)>=6&&(a.rain||0)<6)e.push([b.time,"Heavy rainfall beginning"]);if((b.visibility||99)<2&&(a.visibility||99)>=2)e.push([b.time,"Visibility reducing due to fog"]);if((b.snowfall||0)>0&&(a.snowfall||0)<=0)e.push([b.time,"Snow accumulation increasing"]);if(["rain","heavy-rain"].includes(a.condition.state)&&["clear","partly"].includes(c))e.push([b.time,"Clearing after rainfall"]);if((b.windGusts||0)>=30&&(a.windGusts||0)<30)e.push([b.time,"Strong gusts detected"])}return e.slice(0,40)}
  renderEmpty(){this.root.querySelector("#wrLoc").textContent="No historical observations available for replay.";this.root.querySelector("#wrHelp")?.classList.add("empty")}
  open(){this.load();this.root.classList.add("is-open");document.body.style.overflow="hidden";this.update();this.root.querySelector("#wrClose").focus()}
  close(){this.root.classList.remove("is-open");document.body.style.overflow="";this.pause()}
  bind(){
    const q=id=>this.root.querySelector(id);q("#wrClose").onclick=()=>this.close();q("#wrLocation").onchange=e=>{this.location=e.target.value;this.load()};q("#wrPlay").onclick=()=>this.playing?this.pause():this.play();
    q("#wrBack").onclick=()=>this.step(-1);q("#wrNext").onclick=()=>this.step(1);q("#wrRange").oninput=e=>{this.idx=+e.target.value;this.update()};
    q("#wrSpeed").onchange=e=>this.speed=+e.target.value;q("#wrCamera").onchange=e=>{if(this.renderer)this.renderer.camera=e.target.value};
    q("#wrQuality").value=this.renderer?.pm.quality||"balanced";q("#wrQuality").onchange=e=>{if(this.renderer){this.renderer.pm.set(e.target.value);this.renderer.pm.choose();this.renderer.resize()}};
    q("#wrMotion").onclick=e=>{const on=q("#wrMotion").getAttribute("aria-pressed")==="true";q("#wrMotion").setAttribute("aria-pressed",String(!on));if(this.renderer)this.renderer.reduced=!on};
    q("#wrAudio").onclick=e=>{const on=q("#wrAudio").getAttribute("aria-pressed")==="true";q("#wrAudio").setAttribute("aria-pressed",String(!on));this.audio= !on?this.makeAudio():null};
    q("#wrClean").onclick=e=>{const on=q("#wrClean").getAttribute("aria-pressed")==="true";q("#wrClean").setAttribute("aria-pressed",String(!on));this.root.classList.toggle("clean",!on)};
    addEventListener("keydown",e=>{if(!this.root.classList.contains("is-open"))return;if(e.key==="Escape")this.close();if(e.code==="Space"){e.preventDefault();this.playing?this.pause():this.play()}if(e.key==="ArrowRight")this.step(1);if(e.key==="ArrowLeft")this.step(-1)});
    let sx=0,sy=0,drag=false,c=q(".wr-canvas");c.addEventListener("pointerdown",e=>{sx=e.clientX;sy=e.clientY;drag=true;c.setPointerCapture(e.pointerId)});c.addEventListener("pointerup",e=>{drag=false});c.addEventListener("pointermove",e=>{if(!drag||!this.renderer)return;this.renderer.camera="free";});
  }
  makeAudio(){try{const A=window.AudioContext||window.webkitAudioContext,ac=new A(),o=ac.createOscillator(),g=ac.createGain();o.type="sine";o.frequency.value=70;g.gain.value=.0001;o.connect(g).connect(ac.destination);o.start();return {ac,o,g}}catch(e){return null}}
  play(){if(this.rows.length<2)return;this.playing=true;this.root.querySelector("#wrPlay").textContent="Ⅱ";this.lastTime=performance.now();const tick=(n)=>{if(!this.playing)return;const dt=n-this.lastTime;this.lastTime=n;this._sim=(this._sim||0)+dt*this.speed;const hours=this._sim/500;this._sim%=500;let next=Math.floor(this.idx+hours);if(next!==this.idx){this.idx=Math.min(next,this.rows.length-1);this.update()}if(this.idx>=this.rows.length-1)this.pause();else requestAnimationFrame(tick)};requestAnimationFrame(tick)}
  pause(){this.playing=false;this.root.querySelector("#wrPlay").textContent="▶"}
  step(d){this.idx=clamp(this.idx+d,0,this.rows.length-1);this.update()}
  update(){
    if(!this.rows.length)return;const r=this.engine.at(this.rows,this.rows[this.idx].time),q=this.root.querySelector.bind(this.root),d=new Date(r.time);
    q("#wrRange").max=Math.max(0,this.rows.length-1);q("#wrRange").value=this.idx;
    const local=d.toLocaleString([], {dateStyle:"medium",timeStyle:"short",timeZone:r.timezone||undefined});q("#wrTime").textContent=local;
    q("#wrRangeLabel").textContent=local;q("#wrCond").textContent=r.condition.name;q("#wrTemp").textContent=r.temperature==null?"—":`${fmt(r.temperature)}°`;
    q("#wrRain").textContent=r.precipitation==null?"—":`${fmt(r.precipitation)} mm/h`;q("#wrWind").textContent=r.windSpeed==null?"—":`${fmt(r.windSpeed)} kt @ ${Math.round(r.windDirection||0)}°`;
    q("#wrHum").textContent=r.humidity==null?"—":`${fmt(r.humidity)}%`;q("#wrVis").textContent=r.visibility==null?"—":`${fmt(r.visibility)} km`;
    const conf=this.confidence(r),el=q("#wrConfidence");el.className="wr-confidence "+conf;el.textContent="Data Confidence: "+conf[0].toUpperCase()+conf.slice(1);
    q("#wrLoc").textContent=(r.latitude!=null&&r.longitude!=null)?`${r.latitude.toFixed(2)}°, ${r.longitude.toFixed(2)}° · historical replay`:"Historical replay · location metadata unavailable";
    q("#wrEvents").innerHTML=this.events.map(x=>`<span class="wr-event">${new Date(x[0]).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})} · ${x[1]}</span>`).join("");
    if(this.renderer)this.renderer.setState({...r,sunFactor:this.sunFactor(r),cloudCover:r.cloudCover??0,rain:r.rain??r.precipitation??0,lightning:this.lightning(r)});
  }
  sunFactor(r){const h=new Date(r.time).getUTCHours()+new Date(r.time).getUTCMinutes()/60;return clamp(Math.sin((h-6)/12*Math.PI),0,1)}
  lightning(r){if(r.condition.state!=="thunderstorm")return 0;if(this.renderer?.reduced)return 0;const x=Math.sin(r.time/60000*12.9898)*43758.5453;return (x-Math.floor(x))>.965?.85:0}
}
window.WeatherConditionMapper=WeatherConditionMapper;window.WeatherInterpolationEngine=WeatherInterpolationEngine;window.HistoricalWeatherReplay=HistoricalWeatherReplay;
function start(){if(!window.__FORBSPACE_REPLAY_DISABLED__)window.FORBSPACE_REPLAY=new HistoricalWeatherReplay()}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",start,{once:true});else start();
})();
